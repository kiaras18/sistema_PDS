
package view;

import dao.AnimalDAO;
import model.Animal;
import util.ImagemUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;

public class CadastroAnimalView extends JDialog {

    private JTextField txtNome, txtRaca, txtCor, txtIdade, txtPeso, txtVacinas;
    private JComboBox<String> cbEspecie, cbSexo, cbPorte, cbStatus;
    private JCheckBox chkCastrado;
    private JTextArea txtObservacoes;

    private JLabel lblFoto;
    private String caminhoImagemSelecionado;

    private Animal animalEdicao;
    private Runnable onSalvarCallback;

    public CadastroAnimalView(Frame parent, Animal animal, Runnable onSalvarCallback) {
        super(parent, animal == null ? "Cadastrar Novo Animal" : "Editar Animal", true);

        this.animalEdicao = animal;
        this.onSalvarCallback = onSalvarCallback;

        // Mantém o caminho da foto existente durante a edição.
        if (animal != null) {
            caminhoImagemSelecionado = animal.getCaminhoImagem();
        }

        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setSize(560, 760);
        setLocationRelativeTo(parent);
        setResizable(false);

        initComponents();

        if (animalEdicao != null) {
            preencherCampos();
        }
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(Color.WHITE);

        // Conteúdo principal com rolagem.
        JPanel conteudoPanel = new JPanel();
        conteudoPanel.setLayout(new BoxLayout(conteudoPanel, BoxLayout.Y_AXIS));
        conteudoPanel.setBackground(Color.WHITE);

        // Área da foto.
        JPanel fotoPanel = new JPanel(new BorderLayout(5, 5));
        fotoPanel.setOpaque(false);
        fotoPanel.setBorder(new EmptyBorder(0, 0, 12, 0));
        fotoPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblFoto = new JLabel("Nenhuma foto selecionada", SwingConstants.CENTER);
        lblFoto.setPreferredSize(new Dimension(180, 140));
        lblFoto.setMinimumSize(new Dimension(180, 140));
        lblFoto.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        JButton btnSelecionarFoto = new JButton("Selecionar foto");
        btnSelecionarFoto.addActionListener(e -> selecionarFoto());

        fotoPanel.add(lblFoto, BorderLayout.CENTER);
        fotoPanel.add(btnSelecionarFoto, BorderLayout.SOUTH);

        // Formulário.
        JPanel formPanel = new JPanel(new GridLayout(11, 2, 8, 8));
        formPanel.setOpaque(false);
        formPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtNome = new JTextField();
        cbEspecie = new JComboBox<>(new String[]{"Cachorro", "Gato", "Outro"});
        txtRaca = new JTextField();
        cbSexo = new JComboBox<>(new String[]{"Macho", "Fêmea"});
        txtIdade = new JTextField();
        cbPorte = new JComboBox<>(new String[]{"Pequeno", "Médio", "Grande"});
        txtCor = new JTextField();
        txtPeso = new JTextField();

        cbStatus = new JComboBox<>(new String[]{
        	    "Disponível para adoção",
        	    "Em tratamento",
        	    "Controle veterinário",
        	    "Em observação",
        	    "Adotado",
        	    "Temporariamente indisponível",
        	    "Falecido"
        	});
        chkCastrado = new JCheckBox("Sim");
        chkCastrado.setOpaque(false);

        txtVacinas = new JTextField();

        formPanel.add(new JLabel("Nome:"));
        formPanel.add(txtNome);

        formPanel.add(new JLabel("Espécie:"));
        formPanel.add(cbEspecie);

        formPanel.add(new JLabel("Raça:"));
        formPanel.add(txtRaca);

        formPanel.add(new JLabel("Sexo:"));
        formPanel.add(cbSexo);

        formPanel.add(new JLabel("Idade (anos):"));
        formPanel.add(txtIdade);

        formPanel.add(new JLabel("Porte:"));
        formPanel.add(cbPorte);

        formPanel.add(new JLabel("Cor:"));
        formPanel.add(txtCor);

        formPanel.add(new JLabel("Peso (kg):"));
        formPanel.add(txtPeso);

        formPanel.add(new JLabel("Status:"));
        formPanel.add(cbStatus);

        formPanel.add(new JLabel("Castrado?"));
        formPanel.add(chkCastrado);

        formPanel.add(new JLabel("Vacinas:"));
        formPanel.add(txtVacinas);

        // Observações.
        JPanel obsPanel = new JPanel(new BorderLayout(5, 5));
        obsPanel.setOpaque(false);
        obsPanel.setBorder(new EmptyBorder(12, 0, 5, 0));
        obsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        obsPanel.add(new JLabel("Observações:"), BorderLayout.NORTH);

        txtObservacoes = new JTextArea(4, 20);
        txtObservacoes.setLineWrap(true);
        txtObservacoes.setWrapStyleWord(true);

        obsPanel.add(new JScrollPane(txtObservacoes), BorderLayout.CENTER);

        // Organiza todas as áreas.
        conteudoPanel.add(fotoPanel);
        conteudoPanel.add(formPanel);
        conteudoPanel.add(obsPanel);

        JScrollPane scrollPane = new JScrollPane(conteudoPanel);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Botões.
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setOpaque(false);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBackground(new Color(46, 204, 113));
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.addActionListener(e -> salvar());

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dispose());

        btnPanel.add(btnCancelar);
        btnPanel.add(btnSalvar);

        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private void selecionarFoto() {
        JFileChooser seletor = new JFileChooser();

        FileNameExtensionFilter filtro =
            new FileNameExtensionFilter(
                "Imagens JPG, JPEG e PNG",
                "jpg", "jpeg", "png"
            );

        seletor.setFileFilter(filtro);
        seletor.setAcceptAllFileFilterUsed(false);

        int resultado = seletor.showOpenDialog(this);

        if (resultado != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File arquivo = seletor.getSelectedFile();

        try {
            String novoCaminho = ImagemUtil.salvarFotoLocal(arquivo);

            if (novoCaminho == null) {
                JOptionPane.showMessageDialog(
                    this,
                    "Não foi possível salvar a foto selecionada.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            ImageIcon imagem =
                ImagemUtil.redimensionarImagem(novoCaminho, 180, 140);

            if (imagem == null) {
                JOptionPane.showMessageDialog(
                    this,
                    "Não foi possível abrir essa imagem.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            caminhoImagemSelecionado = novoCaminho;

            lblFoto.setText("");
            lblFoto.setIcon(imagem);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Erro ao copiar a foto: " + ex.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void preencherCampos() {
        txtNome.setText(animalEdicao.getNome());
        cbEspecie.setSelectedItem(animalEdicao.getEspecie());
        txtRaca.setText(animalEdicao.getRaca());
        cbSexo.setSelectedItem(animalEdicao.getSexo());

        txtIdade.setText(String.valueOf(animalEdicao.getIdadeAnos()));
        cbPorte.setSelectedItem(animalEdicao.getPorte());
        txtCor.setText(animalEdicao.getCor());

        txtPeso.setText(
            animalEdicao.getPeso() != null
                ? animalEdicao.getPeso().toString()
                : ""
        );

        cbStatus.setSelectedItem(animalEdicao.getStatus());
        chkCastrado.setSelected(animalEdicao.isCastrado());
        txtVacinas.setText(animalEdicao.getVacinas());
        txtObservacoes.setText(animalEdicao.getObservacoes());

        // Exibe a foto já cadastrada, se existir.
        if (caminhoImagemSelecionado != null
                && !caminhoImagemSelecionado.trim().isEmpty()) {

            ImageIcon imagem = ImagemUtil.redimensionarImagem(
                caminhoImagemSelecionado, 180, 140
            );

            if (imagem != null) {
                lblFoto.setText("");
                lblFoto.setIcon(imagem);
            }
        }
    }

    private void salvar() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "O nome do animal é obrigatório!",
                "Aviso",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Animal a = (animalEdicao == null)
            ? new Animal()
            : animalEdicao;

        a.setNome(txtNome.getText().trim());
        a.setEspecie((String) cbEspecie.getSelectedItem());
        a.setRaca(txtRaca.getText().trim());
        a.setSexo((String) cbSexo.getSelectedItem());

        try {
            String idadeTexto = txtIdade.getText().trim();

            a.setIdadeAnos(
                idadeTexto.isEmpty()
                    ? 0
                    : Integer.parseInt(idadeTexto)
            );

            if (a.getIdadeAnos() < 0) {
                throw new NumberFormatException();
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                this,
                "Idade inválida!",
                "Erro",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        a.setPorte((String) cbPorte.getSelectedItem());
        a.setCor(txtCor.getText().trim());

        try {
            String pesoTexto = txtPeso.getText().trim().replace(",", ".");

            BigDecimal peso = pesoTexto.isEmpty()
                ? new BigDecimal("0.00")
                : new BigDecimal(pesoTexto);

            if (peso.compareTo(BigDecimal.ZERO) < 0) {
                throw new NumberFormatException();
            }

            a.setPeso(peso);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                this,
                "Peso inválido! Use um número positivo, como 5.5.",
                "Erro",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        a.setStatus((String) cbStatus.getSelectedItem());
        a.setCastrado(chkCastrado.isSelected());
        a.setVacinas(txtVacinas.getText().trim());
        a.setObservacoes(txtObservacoes.getText().trim());

        // Guarda o caminho da foto no objeto.
        a.setCaminhoImagem(caminhoImagemSelecionado);

        AnimalDAO dao = new AnimalDAO();

        boolean sucesso = (animalEdicao == null)
            ? dao.salvar(a)
            : dao.atualizar(a);

        if (sucesso) {
            JOptionPane.showMessageDialog(
                this,
                "Animal salvo com sucesso!"
            );

            if (onSalvarCallback != null) {
                onSalvarCallback.run();
            }

            dispose();

        } else {
            JOptionPane.showMessageDialog(
                this,
                "Não foi possível salvar o animal. Confira o console do Eclipse para verificar o erro.",
                "Erro",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
