-- ============================================================
-- SCRIPT DE CRIAÇÃO DO BANCO DE DADOS - ONG ANIMALCARE
-- SGBD: MySQL 8.0+ / MariaDB
-- ============================================================

DROP DATABASE IF EXISTS ong_animalcare;
CREATE DATABASE ong_animalcare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ong_animalcare;

-- ------------------------------------------------------------
-- Tabela: usuarios
-- ------------------------------------------------------------
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha_hash VARCHAR(64) NOT NULL,
    tipo_acesso ENUM('ADMINISTRADOR', 'FUNCIONARIO') NOT NULL,
    categoria ENUM('FUNCIONARIO', 'VOLUNTARIO', 'ADOTANTE') NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    data_nascimento DATE,
    endereco VARCHAR(150),
    cidade VARCHAR(60),
    estado CHAR(2),
    status ENUM('ATIVO', 'INATIVO') DEFAULT 'ATIVO',
    observacoes TEXT,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: animais
-- ------------------------------------------------------------
CREATE TABLE animais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(60) NOT NULL,
    especie ENUM('Cachorro', 'Gato', 'Outros') NOT NULL,
    raca VARCHAR(50) DEFAULT 'SRD',
    sexo ENUM('Macho', 'Femea') NOT NULL,
    data_nascimento_aprox DATE,
    idade_anos INT DEFAULT 0,
    porte ENUM('Pequeno', 'Medio', 'Grande') NOT NULL,
    cor VARCHAR(40),
    peso DECIMAL(5,2) NOT NULL,
    data_resgate DATE NOT NULL,
    local_resgate VARCHAR(150) NOT NULL,
    status ENUM('Disponivel para adocao', 'Em tratamento', 'Controle veterinario', 'Em observacao', 'Adotado', 'Temporariamente indisponivel', 'Falecido') DEFAULT 'Em observacao',
    castrado BOOLEAN DEFAULT FALSE,
    vacinas TEXT,
    observacoes TEXT,
    foto_path VARCHAR(255),
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: voluntarios
-- ------------------------------------------------------------
CREATE TABLE voluntarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL UNIQUE,
    disponibilidade VARCHAR(100) NOT NULL,
    area_atuacao ENUM('Limpeza', 'Alimentacao', 'Passeio', 'Resgate', 'Eventos', 'Administracao', 'Divulgacao', 'Cuidados veterinarios', 'Outras') NOT NULL,
    data_entrada DATE NOT NULL,
    status ENUM('ATIVO', 'INATIVO', 'EM_PAUSA') DEFAULT 'ATIVO',
    observacoes TEXT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: adotantes
-- ------------------------------------------------------------
CREATE TABLE adotantes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL UNIQUE,
    profissao VARCHAR(80),
    renda_estimada DECIMAL(10,2),
    tipo_residencia ENUM('Casa', 'Apartamento', 'Sitio/Chacara') NOT NULL,
    possui_outros_animais BOOLEAN DEFAULT FALSE,
    observacoes TEXT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: adocoes
-- ------------------------------------------------------------
CREATE TABLE adocoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    animal_id INT NOT NULL,
    adotante_id INT NOT NULL,
    funcionario_id INT NOT NULL,
    data_adocao DATE NOT NULL,
    status ENUM('Em analise', 'Aprovada', 'Recusada', 'Concluida', 'Cancelada') DEFAULT 'Em analise',
    observacoes TEXT,
    data_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (animal_id) REFERENCES animais(id),
    FOREIGN KEY (adotante_id) REFERENCES adotantes(id),
    FOREIGN KEY (funcionario_id) REFERENCES usuarios(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: escalas (Já com turno, funcao e status_presenca)
-- ------------------------------------------------------------
CREATE TABLE escalas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    voluntario_id INT NOT NULL,
    data_escala DATE NOT NULL,
    turno VARCHAR(20) DEFAULT 'Manhã',
    funcao VARCHAR(100) DEFAULT 'Cuidados Gerais',
    status_presenca VARCHAR(20) DEFAULT 'Pendente',
    hora_inicio TIME DEFAULT '08:00:00',
    hora_fim TIME DEFAULT '12:00:00',
    atividade VARCHAR(100) DEFAULT 'Geral',
    observacoes TEXT,
    FOREIGN KEY (voluntario_id) REFERENCES voluntarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: presencas
-- ------------------------------------------------------------
CREATE TABLE presencas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    escala_id INT,
    voluntario_id INT NOT NULL,
    data_presenca DATE NOT NULL,
    hora_entrada TIME NOT NULL,
    hora_saida TIME,
    atividade VARCHAR(100) NOT NULL,
    status ENUM('Presente', 'Ausente', 'Atrasado', 'Justificado') DEFAULT 'Presente',
    observacoes TEXT,
    FOREIGN KEY (escala_id) REFERENCES escalas(id) ON DELETE SET NULL,
    FOREIGN KEY (voluntario_id) REFERENCES voluntarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Índices para otimização
-- ------------------------------------------------------------
CREATE INDEX idx_animais_status ON animais(status);
CREATE INDEX idx_animais_especie ON animais(especie);
CREATE INDEX idx_usuarios_cpf ON usuarios(cpf);
CREATE INDEX idx_escalas_data ON escalas(data_escala);
CREATE INDEX idx_presencas_data ON presencas(data_presenca);

-- ------------------------------------------------------------
-- DADOS INICIAIS PARA TESTE
-- Senha padrão para todos: admin123
-- ------------------------------------------------------------

-- Inserção de Usuários
INSERT INTO usuarios (nome, cpf, email, senha_hash, tipo_acesso, categoria, telefone, data_nascimento, endereco, cidade, estado, status) VALUES
('Administrador Geral', '111.111.111-11', 'admin@gmail.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'ADMINISTRADOR', 'FUNCIONARIO', '(47) 99999-1111', '1985-05-10', 'Rua das Flores, 100', 'Blumenau', 'SC', 'ATIVO'),
('Carlos Eduardo Silva', '222.222.222-22', 'carlos@animalcare.org', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'FUNCIONARIO', 'FUNCIONARIO', '(47) 98888-2222', '1990-08-15', 'Av. Brasil, 450', 'Blumenau', 'SC', 'ATIVO'),
('Mariana Souza', '333.333.333-33', 'mariana@gmail.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'FUNCIONARIO', 'VOLUNTARIO', '(47) 97777-3333', '1995-12-20', 'Rua Sete de Setembro, 88', 'Blumenau', 'SC', 'ATIVO'),
('Lucas Rocha', '444.444.444-44', 'lucas@hotmail.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'FUNCIONARIO', 'VOLUNTARIO', '(47) 96666-4444', '1998-03-05', 'Rua XV de Novembro, 1200', 'Blumenau', 'SC', 'ATIVO'),
('Fernanda Lima', '555.555.555-55', 'fernanda@yahoo.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'FUNCIONARIO', 'ADOTANTE', '(47) 95555-5555', '1992-07-25', 'Rua Almirante Tamandaré, 30', 'Blumenau', 'SC', 'ATIVO');

-- Inserção de Voluntários
INSERT INTO voluntarios (usuario_id, disponibilidade, area_atuacao, data_entrada, status, observacoes) VALUES
(3, 'Finais de semana - Manhã', 'Passeio', '2024-01-10', 'ATIVO', 'Experiência prévia com cães grandes'),
(4, 'Terças e Quintas - Tarde', 'Alimentacao', '2024-02-15', 'ATIVO', 'Disponibilidade para transporte de suprimentos');

-- Inserção de Adotantes
INSERT INTO adotantes (usuario_id, profissao, renda_estimada, tipo_residencia, possui_outros_animais, observacoes) VALUES
(5, 'Engenheira de Software', 7500.00, 'Casa', TRUE, 'Possui quintal grande e bem cercado');

-- Inserção de Animais
INSERT INTO animais (nome, especie, raca, sexo, data_nascimento_aprox, idade_anos, porte, cor, peso, data_resgate, local_resgate, status, castrado, vacinas, observacoes) VALUES
('Thor', 'Cachorro', 'Vira-lata (SRD)', 'Macho', '2022-03-10', 3, 'Grande', 'Caramelo', 22.50, '2023-05-10', 'Bairro Centro - Blumenau', 'Disponivel para adocao', TRUE, 'V10, Raiva (Atualizadas)', 'Dócil, brincalhão e sociável com outros cães'),
('Luna', 'Gato', 'Siamês misturado', 'Femea', '2023-01-15', 2, 'Pequeno', 'Cinza/Branco', 3.80, '2023-08-20', 'Bairro Garcia - Blumenau', 'Disponivel para adocao', TRUE, 'V4 Feline, Raiva', 'Muito carinhosa e acostumada em apartamento'),
('Bob', 'Cachorro', 'Poodle', 'Macho', '2019-06-01', 6, 'Medio', 'Branco', 8.20, '2024-01-05', 'Bairro Itoupava Seca', 'Em tratamento', FALSE, 'Raiva', 'Em tratamento dermatológico na pata direita'),
('Mel', 'Gato', 'Persa SRD', 'Femea', '2021-11-20', 3, 'Pequeno', 'Tricolor', 4.10, '2023-11-12', 'Bairro Velha', 'Adotado', TRUE, 'V4, Raiva', 'Adotada por Fernanda Lima'),
('Pipoca', 'Cachorro', 'Pinscher SRD', 'Femea', '2024-02-01', 1, 'Pequeno', 'Preto e Castanho', 4.50, '2024-03-01', 'Terminal Aterro', 'Controle veterinario', TRUE, 'V10 1ª e 2ª dose', 'Aguardando última dose de vacina');

-- Inserção de Adoção
INSERT INTO adocoes (animal_id, adotante_id, funcionario_id, data_adocao, status, observacoes) VALUES
(4, 1, 2, '2024-02-01', 'Concluida', 'Adoção realizada com termo assinado e vistoria aprovada.');

-- Inserção de Escalas
INSERT INTO escalas (voluntario_id, data_escala, turno, funcao, status_presenca, hora_inicio, hora_fim, atividade, observacoes) VALUES
(1, '2026-10-10', 'Manhã', 'Passeio', 'Pendente', '08:00:00', '12:00:00', 'Passeio e Socialização', 'Trazer coleiras extras'),
(2, '2026-10-11', 'Tarde', 'Alimentação', 'Pendente', '13:30:00', '17:30:00', 'Alimentação e Higienização', 'Limpeza dos gatis');

-- Inserção de Presenças
INSERT INTO presencas (escala_id, voluntario_id, data_presenca, hora_entrada, hora_saida, atividade, status) VALUES
(1, 1, '2026-10-10', '07:55:00', '12:05:00', 'Passeio e Socialização', 'Presente');

USE ong_animalcare;

ALTER TABLE animais 
    MODIFY COLUMN data_resgate DATE NULL,
    MODIFY COLUMN local_resgate VARCHAR(150) DEFAULT 'Não informado';
    
    ALTER USER 'root'@'localhost' IDENTIFIED BY '1234';
    
  USE ong_animalcare;

DESCRIBE animais;