package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import model.Animal;

public class AnimalRepository {

    public void inserir(Animal animal) {

        String sql = "INSERT INTO animal "
                   + "(nome, especie, raca, genero, peso, descricao, status, idade) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getEspecie());
            stmt.setString(3, animal.getRaca());
            stmt.setString(4, String.valueOf(animal.getGenero()));
            stmt.setDouble(5, animal.getPeso());
            stmt.setString(6, animal.getDescricao());
            stmt.setString(7, animal.getStatus());
            stmt.setInt(8, animal.getIdade());

            stmt.executeUpdate();

            System.out.println("Animal inserido com sucesso!");

        } catch (Exception e) {

            System.out.println("Erro ao inserir animal:");
            e.printStackTrace();
        }
    }

    public void listar() {

        String sql = "SELECT * FROM animal";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             var resultado = stmt.executeQuery()) {

            while (resultado.next()) {

                System.out.println("ID: " + resultado.getInt("idAnimal"));
                System.out.println("Nome: " + resultado.getString("nome"));
                System.out.println("Espécie: " + resultado.getString("especie"));
                System.out.println("Raça: " + resultado.getString("raca"));
                System.out.println("Gênero: " + resultado.getString("genero"));
                System.out.println("Peso: " + resultado.getDouble("peso"));
                System.out.println("Descrição: " + resultado.getString("descricao"));
                System.out.println("Status: " + resultado.getString("status"));
                System.out.println("Idade: " + resultado.getInt("idade"));
                System.out.println("-------------------------");
            }

        } catch (Exception e) {

            System.out.println("Erro ao listar animais:");
            e.printStackTrace();
        }
    }

    public List<Animal> listarTodos() {

        List<Animal> animais = new ArrayList<>();

        String sql = "SELECT * FROM animal";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             var resultado = stmt.executeQuery()) {

            while (resultado.next()) {

                Animal animal = new Animal();

                animal.setIdAnimal(resultado.getInt("idAnimal"));
                animal.setNome(resultado.getString("nome"));
                animal.setEspecie(resultado.getString("especie"));
                animal.setRaca(resultado.getString("raca"));
                animal.setGenero(resultado.getString("genero").charAt(0));
                animal.setPeso(resultado.getDouble("peso"));
                animal.setDescricao(resultado.getString("descricao"));
                animal.setStatus(resultado.getString("status"));
                animal.setIdade(resultado.getInt("idade"));

                animais.add(animal);
            }

        } catch (Exception e) {

            System.out.println("Erro ao listar animais:");
            e.printStackTrace();
        }

        return animais;
    }

    public void alterar(Animal animal) {

        String sql = "UPDATE animal SET "
                   + "nome = ?, "
                   + "especie = ?, "
                   + "raca = ?, "
                   + "genero = ?, "
                   + "peso = ?, "
                   + "descricao = ?, "
                   + "status = ?, "
                   + "idade = ? "
                   + "WHERE idAnimal = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getEspecie());
            stmt.setString(3, animal.getRaca());
            stmt.setString(4, String.valueOf(animal.getGenero()));
            stmt.setDouble(5, animal.getPeso());
            stmt.setString(6, animal.getDescricao());
            stmt.setString(7, animal.getStatus());
            stmt.setInt(8, animal.getIdade());
            stmt.setInt(9, animal.getIdAnimal());

            stmt.executeUpdate();

            System.out.println("Animal alterado com sucesso!");

        } catch (Exception e) {

            System.out.println("Erro ao alterar animal:");
            e.printStackTrace();
        }
    }

    public void excluir(int idAnimal) {

        String sql = "DELETE FROM animal WHERE idAnimal = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idAnimal);

            stmt.executeUpdate();

            System.out.println("Animal excluído com sucesso!");

        } catch (Exception e) {

            System.out.println("Erro ao excluir animal:");
            e.printStackTrace();
        }
    }
}