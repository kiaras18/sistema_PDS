package repository;

import java.util.ArrayList;
import java.util.List;

import model.Animal;

public class AnimalRepositorio {

    private List<Animal> animais = new ArrayList<>();

    public void salvar(Animal animal) {
        animal.validar();
        animais.add(animal);
    }

    public List<Animal> listarTodos() {
        return new ArrayList<>(animais);
    }

    public int contar() {
        return animais.size();
    }
}