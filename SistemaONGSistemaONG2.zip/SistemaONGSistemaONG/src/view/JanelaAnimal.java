package view;

import javax.swing.*;

import model.Animal;
import repository.AnimalRepository;

public class JanelaAnimal extends JFrame {


private JLabel lblNome;
private JTextField txtNome;

private JLabel lblEspecie;
private JComboBox<String> cbEspecie;

private JLabel lblRaca;
private JTextField txtRaca;

private JLabel lblGenero;
private JComboBox<String> cbGenero;

private JLabel lblPeso;
private JTextField txtPeso;

private JLabel lblIdade;
private JTextField txtIdade;

private JLabel lblStatus;
private JComboBox<String> cbStatus;

private JLabel lblDescricao;
private JTextField txtDescricao;

private JButton btnCadastrar;

public JanelaAnimal() {

    setTitle("Cadastro de Animal");

    setSize(500, 550);

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    setLocationRelativeTo(null);

    setLayout(null);

    // Nome
    lblNome = new JLabel("Nome:");
    lblNome.setBounds(50, 30, 100, 25);
    add(lblNome);

    txtNome = new JTextField();
    txtNome.setBounds(150, 30, 250, 25);
    add(txtNome);

    // Espécie
    lblEspecie = new JLabel("Espécie:");
    lblEspecie.setBounds(50, 80, 100, 25);
    add(lblEspecie);

    cbEspecie = new JComboBox<>();
    cbEspecie.addItem("Cachorro");
    cbEspecie.addItem("Gato");
    cbEspecie.setBounds(150, 80, 250, 25);
    add(cbEspecie);

    // Raça
    lblRaca = new JLabel("Raça:");
    lblRaca.setBounds(50, 130, 100, 25);
    add(lblRaca);

    txtRaca = new JTextField();
    txtRaca.setBounds(150, 130, 250, 25);
    add(txtRaca);

    // Gênero
    lblGenero = new JLabel("Gênero:");
    lblGenero.setBounds(50, 180, 100, 25);
    add(lblGenero);

    cbGenero = new JComboBox<>();
    cbGenero.addItem("M");
    cbGenero.addItem("F");
    cbGenero.setBounds(150, 180, 250, 25);
    add(cbGenero);

    // Peso
    lblPeso = new JLabel("Peso:");
    lblPeso.setBounds(50, 230, 100, 25);
    add(lblPeso);

    txtPeso = new JTextField();
    txtPeso.setBounds(150, 230, 250, 25);
    add(txtPeso);

    // Idade
    lblIdade = new JLabel("Idade:");
    lblIdade.setBounds(50, 280, 100, 25);
    add(lblIdade);

    txtIdade = new JTextField();
    txtIdade.setBounds(150, 280, 250, 25);
    add(txtIdade);

    // Status
    lblStatus = new JLabel("Status:");
    lblStatus.setBounds(50, 330, 100, 25);
    add(lblStatus);

    cbStatus = new JComboBox<>();

    cbStatus.addItem("Disponível");
    cbStatus.addItem("Adotado");
    cbStatus.addItem("Em tratamento");
    cbStatus.addItem("Controle veterinário");

    cbStatus.setBounds(150, 330, 250, 25);
    add(cbStatus);

    // Descrição
    lblDescricao = new JLabel("Descrição:");
    lblDescricao.setBounds(50, 380, 100, 25);
    add(lblDescricao);

    txtDescricao = new JTextField();
    txtDescricao.setBounds(150, 380, 250, 25);
    add(txtDescricao);

    // Botão
    btnCadastrar = new JButton("Cadastrar");
    btnCadastrar.setBounds(180, 440, 140, 30);
    add(btnCadastrar);

    // Ação do botão
    btnCadastrar.addActionListener(e -> {

        try {

            String nome = txtNome.getText();

            String especie =
                cbEspecie.getSelectedItem().toString();

            String raca = txtRaca.getText();

            char genero =
                cbGenero.getSelectedItem().toString().charAt(0);

            double peso =
                Double.parseDouble(txtPeso.getText());

            int idade =
                Integer.parseInt(txtIdade.getText());

            String status =
                cbStatus.getSelectedItem().toString();

            String descricao =
                txtDescricao.getText();

            Animal animal = new Animal();

            animal.setNome(nome);
            animal.setRaca(raca);
            animal.setGenero(genero);
            animal.setPeso(peso);
            animal.setIdade(idade);
            animal.setStatus(status);
            animal.setEspecie(especie);
            animal.setDescricao(descricao);

            animal.validar();
            AnimalRepository repository = new AnimalRepository();

            repository.inserir(animal);
            JOptionPane.showMessageDialog(
                this,
                "Animal válido!\n\n" +
                "Nome: " + animal.getNome() +
                "\nEspécie: " + especie +
                "\nRaça: " + animal.getRaca() +
                "\nGênero: " + animal.getGenero() +
                "\nPeso: " + animal.getPeso() +
                "\nIdade: " + animal.getIdade() +
                "\nStatus: " + animal.getStatus() +
                "\nDescrição: " + animal.getDescricao()
            );

        } catch (NumberFormatException erro) {

            JOptionPane.showMessageDialog(
                this,
                "Peso e idade devem ser números!"
            );

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(
                this,
                erro.getMessage()
            );
        }
    });
}

public static void main(String[] args) {

    JanelaAnimal janela = new JanelaAnimal();

    janela.setVisible(true);
}

}
