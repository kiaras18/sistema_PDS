package main;

import model.Animal;

public class TestRegras {

    public static void main(String[] args) {

        System.out.println("===== TESTE DAS REGRAS DO ANIMAL =====");

        // TESTE 1 - Animal válido

        Animal animal1 = new Animal();

        animal1.setNome("Rex");
        animal1.setEspecie("Cachorro");
        animal1.setRaca("Labrador");
        animal1.setGenero('M');
        animal1.setPeso(20.5);
        animal1.setDescricao("Cachorro dócil");
        animal1.setStatus("Disponível");
        animal1.setIdade(3);

        try {

            animal1.validar();

            System.out.println("TESTE 1: Animal válido - OK");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 1: ERRO - " + e.getMessage());

        }


        // TESTE 2 - Nome vazio

        Animal animal2 = new Animal();

        animal2.setNome("");
        animal2.setEspecie("Cachorro");
        animal2.setRaca("Labrador");
        animal2.setGenero('M');
        animal2.setPeso(20.5);
        animal2.setDescricao("Cachorro dócil");
        animal2.setStatus("Disponível");
        animal2.setIdade(3);

        try {

            animal2.validar();

            System.out.println("TESTE 2: ERRO - deveria rejeitar nome vazio");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 2: Nome vazio - OK");
            System.out.println("Mensagem: " + e.getMessage());

        }


        // TESTE 3 - Raça vazia

        Animal animal3 = new Animal();

        animal3.setNome("Rex");
        animal3.setEspecie("Cachorro");
        animal3.setRaca("");
        animal3.setGenero('M');
        animal3.setPeso(20.5);
        animal3.setDescricao("Cachorro dócil");
        animal3.setStatus("Disponível");
        animal3.setIdade(3);

        try {

            animal3.validar();

            System.out.println("TESTE 3: ERRO - deveria rejeitar raça vazia");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 3: Raça vazia - OK");
            System.out.println("Mensagem: " + e.getMessage());

        }


        // TESTE 4 - Gênero inválido

        Animal animal4 = new Animal();

        animal4.setNome("Rex");
        animal4.setEspecie("Cachorro");
        animal4.setRaca("Labrador");
        animal4.setGenero('X');
        animal4.setPeso(20.5);
        animal4.setDescricao("Cachorro dócil");
        animal4.setStatus("Disponível");
        animal4.setIdade(3);

        try {

            animal4.validar();

            System.out.println("TESTE 4: ERRO - deveria rejeitar gênero inválido");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 4: Gênero inválido - OK");
            System.out.println("Mensagem: " + e.getMessage());

        }


        // TESTE 5 - Peso inválido

        Animal animal5 = new Animal();

        animal5.setNome("Rex");
        animal5.setEspecie("Cachorro");
        animal5.setRaca("Labrador");
        animal5.setGenero('M');
        animal5.setPeso(0);
        animal5.setDescricao("Cachorro dócil");
        animal5.setStatus("Disponível");
        animal5.setIdade(3);

        try {

            animal5.validar();

            System.out.println("TESTE 5: ERRO - deveria rejeitar peso inválido");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 5: Peso inválido - OK");
            System.out.println("Mensagem: " + e.getMessage());

        }


        // TESTE 6 - Descrição vazia

        Animal animal6 = new Animal();

        animal6.setNome("Rex");
        animal6.setEspecie("Cachorro");
        animal6.setRaca("Labrador");
        animal6.setGenero('M');
        animal6.setPeso(20.5);
        animal6.setDescricao("");
        animal6.setStatus("Disponível");
        animal6.setIdade(3);

        try {

            animal6.validar();

            System.out.println("TESTE 6: ERRO - deveria rejeitar descrição vazia");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 6: Descrição vazia - OK");
            System.out.println("Mensagem: " + e.getMessage());

        }


        // TESTE 7 - Status vazio

        Animal animal7 = new Animal();

        animal7.setNome("Rex");
        animal7.setEspecie("Cachorro");
        animal7.setRaca("Labrador");
        animal7.setGenero('M');
        animal7.setPeso(20.5);
        animal7.setDescricao("Cachorro dócil");
        animal7.setStatus("");
        animal7.setIdade(3);

        try {

            animal7.validar();

            System.out.println("TESTE 7: ERRO - deveria rejeitar status vazio");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 7: Status vazio - OK");
            System.out.println("Mensagem: " + e.getMessage());

        }


        // TESTE 8 - Idade negativa

        Animal animal8 = new Animal();

        animal8.setNome("Rex");
        animal8.setEspecie("Cachorro");
        animal8.setRaca("Labrador");
        animal8.setGenero('M');
        animal8.setPeso(20.5);
        animal8.setDescricao("Cachorro dócil");
        animal8.setStatus("Disponível");
        animal8.setIdade(-1);

        try {

            animal8.validar();

            System.out.println("TESTE 8: ERRO - deveria rejeitar idade negativa");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 8: Idade negativa - OK");
            System.out.println("Mensagem: " + e.getMessage());

        }


        // TESTE 9 - Espécie vazia

        Animal animal9 = new Animal();

        animal9.setNome("Rex");
        animal9.setEspecie("");
        animal9.setRaca("Labrador");
        animal9.setGenero('M');
        animal9.setPeso(20.5);
        animal9.setDescricao("Cachorro dócil");
        animal9.setStatus("Disponível");
        animal9.setIdade(3);

        try {

            animal9.validar();

            System.out.println("TESTE 9: ERRO - deveria rejeitar espécie vazia");

        } catch (IllegalArgumentException e) {

            System.out.println("TESTE 9: Espécie vazia - OK");
            System.out.println("Mensagem: " + e.getMessage());

        }


        System.out.println("======================================");
        System.out.println("FIM DOS TESTES");

    }

}