package main;

import model.Animal;
import repository.AnimalRepository;

public class TestAnimal {

    public static void main(String[] args) {

        Animal animal = new Animal();

        animal.setNome("Rex");
        animal.setEspecie("Cachorro");
        animal.setRaca("Labrador");
        animal.setGenero('M');
        animal.setPeso(25.5);
        animal.setDescricao("Cachorro dócil e brincalhão.");
        animal.setStatus("Disponível");
        animal.setIdade(3);

        animal.validar();

        AnimalRepository repository = new AnimalRepository();

        repository.inserir(animal);

        repository.listar();

        animal.setIdAnimal(1);

        animal.setNome("Thor");

        repository.alterar(animal);

        repository.listar();

        repository.excluir(4);

        repository.listar();

        System.out.println("===== LISTA DE ANIMAIS =====");

        for (Animal a : repository.listarTodos()) {

            System.out.println("ID: " + animal.getIdAnimal());
            System.out.println("Nome: " + animal.getNome());
            System.out.println("Espécie: " + animal.getEspecie());
            System.out.println("Raça: " + animal.getRaca());
            System.out.println("Gênero: " + animal.getGenero());
            System.out.println("Peso: " + animal.getPeso());
            System.out.println("Descrição: " + animal.getDescricao());
            System.out.println("Status: " + animal.getStatus());
            System.out.println("Idade: " + animal.getIdade());
            System.out.println("-------------------------");
        }
    }
}