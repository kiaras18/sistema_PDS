package model;

public class Animal {

	private int idAnimal;
	private String nome;
	private String especie;
	private String raca;
	private char genero;
	private double peso;
	private String descricao;
	private String status;
	private int idade;
    

    public int getIdAnimal() {
        return idAnimal;
    }

    public void setIdAnimal(int idAnimal) {
        this.idAnimal = idAnimal;
    }
    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
    public void validar() {
    	
    	

    	    if (nome == null || nome.trim().isEmpty()) {
    	        throw new IllegalArgumentException("O nome não pode ser vazio.");
    	    }

    	    if (especie == null || especie.trim().isEmpty()) {
    	        throw new IllegalArgumentException("A espécie não pode ser vazia.");
    	    }

    	    if (raca == null || raca.trim().isEmpty()) {
    	        throw new IllegalArgumentException("A raça não pode ser vazia.");
    	    }

    	    if (especie == null || especie.trim().isEmpty()) {
    	        throw new IllegalArgumentException("A espécie não pode ser vazia.");
    	    }

        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("O nome não pode ser vazio.");
        }

        if (raca == null || raca.trim().isEmpty()) {
            throw new IllegalArgumentException("A raça não pode ser vazia.");
        }

        if (genero != 'M' && genero != 'F') {
            throw new IllegalArgumentException("O gênero deve ser M ou F.");
        }

        if (peso <= 0 || peso >= 100) {
            throw new IllegalArgumentException("O peso deve ser maior que 0 e menor que 100.");
        }

        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("A descrição não pode ser vazia.");
        }

        if (status == null || status.trim().isEmpty()) {
            throw new IllegalArgumentException("O status não pode ser vazio.");
        }

        if (idade < 0) {
            throw new IllegalArgumentException("A idade não pode ser negativa.");
        }
    }
}