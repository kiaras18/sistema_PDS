package main;

import model.Animal;
import repository.AnimalRepository;

public class TestAnimal {

    public static void main(String[] args) {

        Animal animal = new Animal();

        animal.setNome("Rex");
        animal.setRaca("Labrador");
        animal.setGenero('M');
        animal.setPeso(25.5);
        animal.setDescricao("Cachorro dócil e brincalhão.");
        animal.setStatus("Disponível");
        animal.setIdade(3);

        animal.validar();
        
        AnimalRepository repository = new AnimalRepository();

        repository.inserir(animal);

        repository.listar();
        
        animal.setIdAnimal(1);

        animal.setNome("Thor");

        repository.alterar(animal);

        repository.listar();
        
        repository.excluir(4);

        repository.listar();
    }
    
}