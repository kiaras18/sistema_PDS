package main;

import java.sql.Connection;

import repository.Conexao;

public class TestConexao {

    public static void main(String[] args) {

        try {
            Connection conexao = Conexao.conectar();

            System.out.println("Conexão realizada com sucesso!");

            conexao.close();

        } catch (Exception e) {
            System.out.println("Erro na conexão:");
            e.printStackTrace();
        }
    }
}