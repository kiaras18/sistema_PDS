//package main;
//
//import model.Animal;
//import repository.AnimalRepository;
//
//public class TestRegras {
//
//    public static void main(String[] args) {
//
//        Animal animal = new Animal();
//
//        animal.setNome("Rex");
//        animal.setRaca("Labrador");
//        animal.setGenero('M');
//        animal.setPeso(20.5);
//        animal.setDescricao("Cachorro dócil");
//        animal.setStatus("disponível");
//        animal.setIdade(3);
//
//        try {
//            animal.validar();
//            System.out.println("Animal válido!");
//            AnimalRepository repository = new AnimalRepository();
//
//            repository.salvar(animal);
//
//            System.out.println("Quantidade de animais: " + repository.listar().size());
//        } catch (IllegalArgumentException e) {
//            System.out.println("Erro: " + e.getMessage());
//        }
//    }
//}