package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;

import model.Animal;

public class AnimalRepository {

    public void inserir(Animal animal) {

        String sql = "INSERT INTO animal "
                   + "(nome, raca, genero, peso, descricao, status, idade) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getRaca());
            stmt.setString(3, String.valueOf(animal.getGenero()));
            stmt.setDouble(4, animal.getPeso());
            stmt.setString(5, animal.getDescricao());
            stmt.setString(6, animal.getStatus());
            stmt.setInt(7, animal.getIdade());

            stmt.executeUpdate();

            System.out.println("Animal inserido com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao inserir animal:");
            e.printStackTrace();
        }
    }

    public void listar() {

        String sql = "SELECT * FROM animal";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             var resultado = stmt.executeQuery()) {

            while (resultado.next()) {

                System.out.println("ID: " + resultado.getInt("idAnimal"));
                System.out.println("Nome: " + resultado.getString("nome"));
                System.out.println("Raça: " + resultado.getString("raca"));
                System.out.println("Gênero: " + resultado.getString("genero"));
                System.out.println("Peso: " + resultado.getDouble("peso"));
                System.out.println("Descrição: " + resultado.getString("descricao"));
                System.out.println("Status: " + resultado.getString("status"));
                System.out.println("Idade: " + resultado.getInt("idade"));
                System.out.println("-------------------------");
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar animais:");
            e.printStackTrace();
        }
    }
    public void alterar(Animal animal) {

        String sql = "UPDATE animal SET "
                   + "nome = ?, "
                   + "raca = ?, "
                   + "genero = ?, "
                   + "peso = ?, "
                   + "descricao = ?, "
                   + "status = ?, "
                   + "idade = ? "
                   + "WHERE idAnimal = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getRaca());
            stmt.setString(3, String.valueOf(animal.getGenero()));
            stmt.setDouble(4, animal.getPeso());
            stmt.setString(5, animal.getDescricao());
            stmt.setString(6, animal.getStatus());
            stmt.setInt(7, animal.getIdade());
            stmt.setInt(8, animal.getIdAnimal());

            stmt.executeUpdate();

            System.out.println("Animal alterado com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao alterar animal:");
            e.printStackTrace();
        }
    }
    public void excluir(int idAnimal) {

        String sql = "DELETE FROM animal WHERE idAnimal = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idAnimal);

            stmt.executeUpdate();

            System.out.println("Animal excluído com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao excluir animal:");
            e.printStackTrace();
        }
    }
}