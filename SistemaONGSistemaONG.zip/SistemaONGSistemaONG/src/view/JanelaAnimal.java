package view;

import javax.swing.*;

public class JanelaAnimal extends JFrame {

    private JLabel lblNome;
    private JTextField txtNome;

    private JLabel lblEspecie;
    private JTextField txtEspecie;

    private JLabel lblIdade;
    private JTextField txtIdade;

    private JButton btnCadastrar;

    public JanelaAnimal() {

        setTitle("Cadastro de Animal");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Layout
        setLayout(null);

        // Nome
        lblNome = new JLabel("Nome:");
        lblNome.setBounds(50, 50, 100, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(150, 50, 250, 25);
        add(txtNome);

        // Espécie
        lblEspecie = new JLabel("Espécie:");
        lblEspecie.setBounds(50, 100, 100, 25);
        add(lblEspecie);

        txtEspecie = new JTextField();
        txtEspecie.setBounds(150, 100, 250, 25);
        add(txtEspecie);

        // Idade
        lblIdade = new JLabel("Idade:");
        lblIdade.setBounds(50, 150, 100, 25);
        add(lblIdade);

        txtIdade = new JTextField();
        txtIdade.setBounds(150, 150, 250, 25);
        add(txtIdade);

        // Botão
        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(180, 220, 140, 30);
        add(btnCadastrar);
        
        btnCadastrar.addActionListener(e -> {

            String nome = txtNome.getText();
            String especie = txtEspecie.getText();
            String idade = txtIdade.getText();

            if (nome.isEmpty() || especie.isEmpty() || idade.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Preencha todos os campos!"
                );

                return;
            }

            try {

                int idadeAnimal = Integer.parseInt(idade);

            } catch (NumberFormatException erro) {

                JOptionPane.showMessageDialog(
                    this,
                    "A idade deve ser um número!"
                );

                return;
            }

            JOptionPane.showMessageDialog(
                this,
                "Animal cadastrado!\n\n" +
                "Nome: " + nome +
                "\nEspécie: " + especie +
                "\nIdade: " + idade
            );
        });
    }

    public static void main(String[] args) {

        JanelaAnimal janela = new JanelaAnimal();

        janela.setVisible(true);
    }
}