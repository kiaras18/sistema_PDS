package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VoluntarioPanel extends JPanel {

    private JTextField txtNome, txtCPF, txtTelefone, txtEmail;
    private JComboBox<String> cbFuncao, cbDisponibilidade;
    private JTable tabelaVoluntarios;
    private DefaultTableModel tableModel;

    public VoluntarioPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(Color.WHITE);

        initComponents();
    }

    private void initComponents() {
        // Título
        JLabel lblTitulo = new JLabel("🤝 Gestão de Voluntários");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(44, 62, 80));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        panelCenter.setOpaque(false);

        // Formulário
        JPanel panelForm = new JPanel(new GridLayout(3, 4, 10, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Dados do Voluntário"));
        panelForm.setBackground(Color.WHITE);

        txtNome = new JTextField();
        txtCPF = new JTextField();
        txtTelefone = new JTextField();
        txtEmail = new JTextField();
        cbFuncao = new JComboBox<>(new String[]{"Veterinário(a)", "Resgate", "Feira de Adoção", "Limpeza / Cuidados", "Administrativo"});
        cbDisponibilidade = new JComboBox<>(new String[]{"Dias da Semana", "Finais de Semana", "Integral", "Flexível"});

        panelForm.add(new JLabel("Nome Completo:"));
        panelForm.add(txtNome);
        panelForm.add(new JLabel("CPF:"));
        panelForm.add(txtCPF);
        panelForm.add(new JLabel("Telefone:"));
        panelForm.add(txtTelefone);
        panelForm.add(new JLabel("E-mail:"));
        panelForm.add(txtEmail);
        panelForm.add(new JLabel("Função Principal:"));
        panelForm.add(cbFuncao);
        panelForm.add(new JLabel("Disponibilidade:"));
        panelForm.add(cbDisponibilidade);

        // Botões
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotoes.setOpaque(false);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnLimpar = new JButton("Limpar");
        JButton btnExcluir = new JButton("Excluir");

        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnLimpar);
        panelBotoes.add(btnExcluir);

        JPanel panelTopContainer = new JPanel(new BorderLayout());
        panelTopContainer.setOpaque(false);
        panelTopContainer.add(panelForm, BorderLayout.CENTER);
        panelTopContainer.add(panelBotoes, BorderLayout.SOUTH);

        panelCenter.add(panelTopContainer, BorderLayout.NORTH);

        // Tabela
        String[] colunas = {"ID", "Nome", "CPF", "Telefone", "E-mail", "Função", "Disponibilidade"};
        tableModel = new DefaultTableModel(colunas, 0);
        tabelaVoluntarios = new JTable(tableModel);

        panelCenter.add(new JScrollPane(tabelaVoluntarios), BorderLayout.CENTER);

        add(panelCenter, BorderLayout.CENTER);
    }
}