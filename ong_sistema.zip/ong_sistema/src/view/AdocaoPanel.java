package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdocaoPanel extends JPanel {

    private JComboBox<String> cbAnimais;
    private JComboBox<String> cbAdotantes;
    private JTextField txtDataAdocao, txtObservacoes;
    private JTable tabelaAdocoes;
    private DefaultTableModel tableModel;

    public AdocaoPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(Color.WHITE);

        initComponents();
    }

    private void initComponents() {
        JLabel lblTitulo = new JLabel("📋 Registro e Histórico de Adoções");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(44, 62, 80));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        panelCenter.setOpaque(false);

        JPanel panelForm = new JPanel(new GridLayout(2, 4, 10, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Nova Adoção"));
        panelForm.setBackground(Color.WHITE);

        cbAnimais = new JComboBox<>();
        cbAdotantes = new JComboBox<>();
        txtDataAdocao = new JTextField();
        txtObservacoes = new JTextField();

        panelForm.add(new JLabel("Selecione o Animal:"));
        panelForm.add(cbAnimais);
        panelForm.add(new JLabel("Selecione o Adotante:"));
        panelForm.add(cbAdotantes);
        panelForm.add(new JLabel("Data (dd/mm/aaaa):"));
        panelForm.add(txtDataAdocao);
        panelForm.add(new JLabel("Observações:"));
        panelForm.add(txtObservacoes);

        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotoes.setOpaque(false);

        JButton btnConfirmar = new JButton("Registrar Adoção");
        JButton btnCancelar = new JButton("Cancelar / Limpar");

        panelBotoes.add(btnConfirmar);
        panelBotoes.add(btnCancelar);

        JPanel panelTopContainer = new JPanel(new BorderLayout());
        panelTopContainer.setOpaque(false);
        panelTopContainer.add(panelForm, BorderLayout.CENTER);
        panelTopContainer.add(panelBotoes, BorderLayout.SOUTH);

        panelCenter.add(panelTopContainer, BorderLayout.NORTH);

        String[] colunas = {"ID Adoção", "Animal", "Adotante", "Data", "Observações"};
        tableModel = new DefaultTableModel(colunas, 0);
        tabelaAdocoes = new JTable(tableModel);

        panelCenter.add(new JScrollPane(tabelaAdocoes), BorderLayout.CENTER);

        add(panelCenter, BorderLayout.CENTER);
    }

    /**
     * Atualiza dinamicamente as listas suspensas (ComboBoxes) buscando
     * os dados atualizados do banco/DAO.
     */
    public void carregarCombos() {
        cbAnimais.removeAllItems();
        cbAdotantes.removeAllItems();

        // Exemplo fictício - Substitua com chamadas ao seu DAO / Controller:
        // List<Animal> animais = animalDAO.listarDisponiveis();
        cbAnimais.addItem("-- Selecione --");
        cbAnimais.addItem("Rex (Cachorro - ID 1)");
        cbAnimais.addItem("Mimi (Gato - ID 2)");

        // List<Adotante> adotantes = adotanteDAO.listarTodos();
        cbAdotantes.addItem("-- Selecione --");
        cbAdotantes.addItem("Carlos Silva (CPF: 123...)");
        cbAdotantes.addItem("Ana Maria (CPF: 456...)");
    }
}