package view;

import database.Conexao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class TesteConexaoApp {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Connection conn = Conexao.getConexao();
            if (conn != null) {
                try {
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS total FROM animais");
                    int totalAnimais = 0;
                    if (rs.next()) {
                        totalAnimais = rs.getInt("total");
                    }
                    Conexao.fecharRecursos(stmt, rs);

                    String msg = String.format("✓ Conexao com o Banco de Dados realizada com SUCESSO!\nTotal de animais cadastrados na base: %d", totalAnimais);
                    JOptionPane.showMessageDialog(null, msg, "ONG AnimalCare - Status Conexao", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Erro ao executar consulta de teste: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                } finally {
                    Conexao.fecharConexao();
                }
            }
        });
    }
}