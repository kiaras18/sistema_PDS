package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdotantePanel extends JPanel {

    private JTextField txtNome, txtCPF, txtTelefone, txtEmail, txtEndereco;
    private JTable tabelaAdotantes;
    private DefaultTableModel tableModel;

    public AdotantePanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(Color.WHITE);

        initComponents();
    }

    private void initComponents() {
        JLabel lblTitulo = new JLabel("Gestão de Adotantes");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(44, 62, 80));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        panelCenter.setOpaque(false);

        JPanel panelForm = new JPanel(new GridLayout(3, 4, 10, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Dados do Adotante"));
        panelForm.setBackground(Color.WHITE);

        txtNome = new JTextField();
        txtCPF = new JTextField();
        txtTelefone = new JTextField();
        txtEmail = new JTextField();
        txtEndereco = new JTextField();

        panelForm.add(new JLabel("Nome Completo:"));
        panelForm.add(txtNome);
        panelForm.add(new JLabel("CPF:"));
        panelForm.add(txtCPF);
        panelForm.add(new JLabel("Telefone:"));
        panelForm.add(txtTelefone);
        panelForm.add(new JLabel("E-mail:"));
        panelForm.add(txtEmail);
        panelForm.add(new JLabel("Endereço:"));
        panelForm.add(txtEndereco);

        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotoes.setOpaque(false);
        panelBotoes.add(new JButton("Salvar"));
        panelBotoes.add(new JButton("Limpar"));
        panelBotoes.add(new JButton("Excluir"));

        JPanel panelTopContainer = new JPanel(new BorderLayout());
        panelTopContainer.setOpaque(false);
        panelTopContainer.add(panelForm, BorderLayout.CENTER);
        panelTopContainer.add(panelBotoes, BorderLayout.SOUTH);

        panelCenter.add(panelTopContainer, BorderLayout.NORTH);

        String[] colunas = {"ID", "Nome", "CPF", "Telefone", "E-mail", "Endereço"};
        tableModel = new DefaultTableModel(colunas, 0);
        tabelaAdotantes = new JTable(tableModel);

        panelCenter.add(new JScrollPane(tabelaAdotantes), BorderLayout.CENTER);

        add(panelCenter, BorderLayout.CENTER);
    }
}