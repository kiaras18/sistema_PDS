package view;

import dao.UsuarioDAO;
import model.Usuario;
import util.SessaoUsuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginView extends JFrame {

    private JTextField txtLogin;
    private JPasswordField txtSenha;

    public LoginView() {
        setTitle("ONG AnimalCare - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        JPanel panelRoot = new JPanel(new BorderLayout(10, 10));
        panelRoot.setBorder(new EmptyBorder(20, 30, 20, 30));
        panelRoot.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("🐾 AnimalCare Login", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(31, 45, 61));
        panelRoot.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelForm = new JPanel(new GridLayout(4, 1, 5, 5));
        panelForm.setOpaque(false);

        txtLogin = new JTextField();
        txtSenha = new JPasswordField();

        panelForm.add(new JLabel("E-mail ou CPF:"));
        panelForm.add(txtLogin);
        panelForm.add(new JLabel("Senha:"));
        panelForm.add(txtSenha);

        panelRoot.add(panelForm, BorderLayout.CENTER);

        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBotoes.setOpaque(false);

        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnEntrar.setBackground(new Color(46, 204, 113));
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setFocusPainted(false);
        btnEntrar.setPreferredSize(new Dimension(120, 35));

        btnEntrar.addActionListener(e -> autenticar());

        panelBotoes.add(btnEntrar);
        panelRoot.add(panelBotoes, BorderLayout.SOUTH);

        add(panelRoot);
    }

    private void autenticar() {
        String loginOuEmail = txtLogin.getText().trim();
        String senha = new String(txtSenha.getPassword()).trim();

        if (loginOuEmail.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o e-mail/CPF e a senha!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        UsuarioDAO dao = new UsuarioDAO();
        Usuario user = dao.autenticar(loginOuEmail, senha);

        if (user != null) {
            SessaoUsuario.iniciarSessao(user);
            this.dispose();
            SwingUtilities.invokeLater(() -> new MenuPrincipalView().setVisible(true));
        } else {
            JOptionPane.showMessageDialog(this, "Usuário ou senha inválidos!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginView().setVisible(true));
    }
}