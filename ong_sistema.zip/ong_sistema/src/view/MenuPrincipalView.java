package view;

import dao.AnimalDAO;
import util.SessaoUsuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MenuPrincipalView extends JFrame {

    private JLabel lblTotalAnimais, lblAnimaisDisponiveis, lblUsuarioLogado;

    public MenuPrincipalView() {
        setTitle("ONG AnimalCare - Menu Principal");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initComponents();
        atualizarDashboard();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(new Color(245, 247, 250));

        // Cabeçalho
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel lblTitulo = new JLabel("🐾 Sistema ONG AnimalCare");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(44, 62, 80));

        String nomeUsuario = SessaoUsuario.getUsuarioLogado() != null ? SessaoUsuario.getUsuarioLogado().getNome() : "Usuário";
        String perfil = SessaoUsuario.isAdmin() ? "ADMINISTRADOR" : "FUNCIONÁRIO";
        lblUsuarioLogado = new JLabel("Olá, " + nomeUsuario + " (" + perfil + ")");
        lblUsuarioLogado.setFont(new Font("Segoe UI", Font.ITALIC, 13));

        headerPanel.add(lblTitulo, BorderLayout.WEST);
        headerPanel.add(lblUsuarioLogado, BorderLayout.EAST);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Painel de Resumo / Cards Informáticos
        JPanel cardsPanel = new JPanel(new GridLayout(1, 2, 15, 15));
        cardsPanel.setOpaque(false);

        lblTotalAnimais = new JLabel("0", SwingConstants.CENTER);
        lblTotalAnimais.setFont(new Font("Segoe UI", Font.BOLD, 28));

        lblAnimaisDisponiveis = new JLabel("0", SwingConstants.CENTER);
        lblAnimaisDisponiveis.setFont(new Font("Segoe UI", Font.BOLD, 28));

        cardsPanel.add(criarCard("Total de Animais", lblTotalAnimais, new Color(52, 152, 219)));
        cardsPanel.add(criarCard("Disponíveis p/ Adoção", lblAnimaisDisponiveis, new Color(46, 204, 113)));

        mainPanel.add(cardsPanel, BorderLayout.CENTER);

        // Menu de Botões / Ações
        JPanel menuPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        menuPanel.setOpaque(false);

        JButton btnAnimais = criarBotaoMenu("🐶 Gerenciar Animais", new Color(52, 73, 94));
        btnAnimais.addActionListener(e -> {
            new ListagemAnimalView().setVisible(true);
            atualizarDashboard();
        });

        JButton btnVoluntarios = criarBotaoMenu("👥 Gerenciar Voluntários", new Color(155, 89, 182));
        btnVoluntarios.addActionListener(e -> new ListagemVoluntariosView().setVisible(true));

        JButton btnAdocoes = criarBotaoMenu("🏠 Registrar Adoção", new Color(230, 126, 34));
        btnAdocoes.addActionListener(e -> {
            new RegistrarAdocaoView().setVisible(true);
            atualizarDashboard();
        });

        JButton btnSair = criarBotaoMenu("🚪 Sair / Logout", new Color(231, 76, 60));
        btnSair.addActionListener(e -> {
            SessaoUsuario.encerrarSessao();
            dispose();
            new LoginView().setVisible(true);
        });

        menuPanel.add(btnAnimais);
        menuPanel.add(btnVoluntarios);
        menuPanel.add(btnAdocoes);
        menuPanel.add(btnSair);

        mainPanel.add(menuPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel criarCard(String titulo, JLabel lblValor, Color cor) {
        JPanel card = new JPanel(new BorderLayout(5, 5));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(cor, 2),
                new EmptyBorder(10, 10, 10, 10)
        ));

        JLabel lblTit = new JLabel(titulo, SwingConstants.CENTER);
        lblTit.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTit.setForeground(cor);

        card.add(lblTit, BorderLayout.NORTH);
        card.add(lblValor, BorderLayout.CENTER);
        return card;
    }

    private JButton criarBotaoMenu(String texto, Color cor) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(cor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        return btn;
    }

    public void atualizarDashboard() {
        AnimalDAO dao = new AnimalDAO();
        lblTotalAnimais.setText(String.valueOf(dao.contarTotal()));
        lblAnimaisDisponiveis.setText(String.valueOf(dao.contarDisponiveis()));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuPrincipalView().setVisible(true));
    }
}