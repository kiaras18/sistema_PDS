package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AnimalPanel extends JPanel {

    private JTextField txtNome, txtRaca, txtIdade;
    private JComboBox<String> cbEspecie, cbPorte, cbStatus;
    private JTable tabelaAnimais;
    private DefaultTableModel tableModel;

    public AnimalPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(Color.WHITE);

        initComponents();
    }

    private void initComponents() {
        // Título da Seção
        JLabel lblTitulo = new JLabel("🐶 Gestão de Animais");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(44, 62, 80));
        add(lblTitulo, BorderLayout.NORTH);

        // Painel Central (Formulário + Tabela)
        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        panelCenter.setOpaque(false);

        // Formulário de Cadastro
        JPanel panelForm = new JPanel(new GridLayout(4, 4, 10, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Dados do Animal"));
        panelForm.setBackground(Color.WHITE);

        txtNome = new JTextField();
        cbEspecie = new JComboBox<>(new String[]{"Cachorro", "Gato", "Outro"});
        txtRaca = new JTextField();
        txtIdade = new JTextField();
        cbPorte = new JComboBox<>(new String[]{"Pequeno", "Médio", "Grande"});
        cbStatus = new JComboBox<>(new String[]{"Disponível", "Adotado", "Em Tratamento"});

        panelForm.add(new JLabel("Nome:"));
        panelForm.add(txtNome);
        panelForm.add(new JLabel("Espécie:"));
        panelForm.add(cbEspecie);
        panelForm.add(new JLabel("Raça:"));
        panelForm.add(txtRaca);
        panelForm.add(new JLabel("Idade (anos):"));
        panelForm.add(txtIdade);
        panelForm.add(new JLabel("Porte:"));
        panelForm.add(cbPorte);
        panelForm.add(new JLabel("Status:"));
        panelForm.add(cbStatus);

        // Botões de Ação
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotoes.setOpaque(false);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnLimpar = new JButton("Limpar");
        JButton btnExcluir = new JButton("Excluir");

        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnLimpar);
        panelBotoes.add(btnExcluir);

        JPanel panelTopContainer = new JPanel(new BorderLayout());
        panelTopContainer.setOpaque(false);
        panelTopContainer.add(panelForm, BorderLayout.CENTER);
        panelTopContainer.add(panelBotoes, BorderLayout.SOUTH);

        panelCenter.add(panelTopContainer, BorderLayout.NORTH);

        // Tabela de Animais
        String[] colunas = {"ID", "Nome", "Espécie", "Raça", "Idade", "Porte", "Status"};
        tableModel = new DefaultTableModel(colunas, 0);
        tabelaAnimais = new JTable(tableModel);
        JScrollPane scrollTabela = new JScrollPane(tabelaAnimais);

        panelCenter.add(scrollTabela, BorderLayout.CENTER);

        add(panelCenter, BorderLayout.CENTER);
    }

    public void carregarTabela() {
        // Método para carregar lista de animais vinda do DAO / Controller
    }
}