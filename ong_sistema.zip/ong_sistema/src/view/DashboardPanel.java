package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class DashboardPanel extends JPanel {

    private JLabel lblTotalAnimais;
    private JLabel lblTotalAdocoes;
    private JLabel lblTotalVoluntarios;
    private JLabel lblAnimaisDisponiveis;

    public DashboardPanel() {
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(20, 20, 20, 20));
        setBackground(new Color(245, 247, 250));

        initComponents();
        atualizarIndicadores();
    }

    private void initComponents() {
        // Título
        JLabel lblTitulo = new JLabel("📊 Painel de Controle - Visão Geral da ONG");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(44, 62, 80));
        add(lblTitulo, BorderLayout.NORTH);

        // Grid de Cartões de Indicadores (KPIs)
        JPanel panelCards = new JPanel(new GridLayout(2, 2, 20, 20));
        panelCards.setOpaque(false);

        lblTotalAnimais = new JLabel("0", SwingConstants.CENTER);
        lblTotalAdocoes = new JLabel("0", SwingConstants.CENTER);
        lblTotalVoluntarios = new JLabel("0", SwingConstants.CENTER);
        lblAnimaisDisponiveis = new JLabel("0", SwingConstants.CENTER);

        panelCards.add(criarCard("Total de Animais", lblTotalAnimais, new Color(52, 152, 219)));
        panelCards.add(criarCard("Animais para Adoção", lblAnimaisDisponiveis, new Color(46, 204, 113)));
        panelCards.add(criarCard("Adoções Realizadas", lblTotalAdocoes, new Color(155, 89, 182)));
        panelCards.add(criarCard("Voluntários Ativos", lblTotalVoluntarios, new Color(241, 196, 15)));

        add(panelCards, BorderLayout.CENTER);
    }

    private JPanel criarCard(String titulo, JLabel lblValor, Color corBorda) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(4, 0, 0, 0, corBorda),
                new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel lblTituloCard = new JLabel(titulo, SwingConstants.CENTER);
        lblTituloCard.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTituloCard.setForeground(new Color(127, 140, 141));

        lblValor.setFont(new Font("Segoe UI", Font.BOLD, 36));
        lblValor.setForeground(new Color(44, 62, 80));

        card.add(lblTituloCard, BorderLayout.NORTH);
        card.add(lblValor, BorderLayout.CENTER);

        return card;
    }

    /**
     * Atualiza os números exibidos nos cartões consultando os DAOs
     */
    public void atualizarIndicadores() {
        // Exemplo: Substituir depois por chamadas reais dos DAOs
        // lblTotalAnimais.setText(String.valueOf(animalDAO.contarTotal()));
        lblTotalAnimais.setText("42");
        lblAnimaisDisponiveis.setText("18");
        lblTotalAdocoes.setText("124");
        lblTotalVoluntarios.setText("15");
    }
}