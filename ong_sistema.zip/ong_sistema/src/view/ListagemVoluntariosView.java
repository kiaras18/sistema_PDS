package view;

import dao.VoluntarioDAO;
import model.Voluntario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ListagemVoluntariosView extends JFrame {

    private JTable tabela;
    private DefaultTableModel model;
    private VoluntarioDAO voluntarioDAO = new VoluntarioDAO();

    public ListagemVoluntariosView() {
        setTitle("ONG AnimalCare - Lista de Voluntários");
        setSize(800, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        carregarVoluntarios();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("👥 Voluntários Cadastrados");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        mainPanel.add(lblTitulo, BorderLayout.NORTH);

        String[] colunas = {"ID", "Nome", "Telefone", "Área de Atuação", "Disponibilidade", "Data Entrada", "Status"};
        model = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        tabela = new JTable(model);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        mainPanel.add(new JScrollPane(tabela), BorderLayout.CENTER);

        add(mainPanel);
    }

    private void carregarVoluntarios() {
        model.setRowCount(0);
        List<Voluntario> lista = voluntarioDAO.listarTodos();

        for (Voluntario v : lista) {
            model.addRow(new Object[]{
                v.getId(),
                v.getNomeUsuario(),
                v.getTelefoneUsuario(),
                v.getAreaAtuacao(),
                v.getDisponibilidade(),
                v.getDataEntrada(),
                v.getStatus()
            });
        }
    }
}