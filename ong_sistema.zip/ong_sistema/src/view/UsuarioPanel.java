package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class UsuarioPanel extends JPanel {

    private JTextField txtNome, txtLogin;
    private JPasswordField txtSenha;
    private JComboBox<String> cbTipoAcesso, cbStatus;
    private JTable tabelaUsuarios;
    private DefaultTableModel tableModel;

    public UsuarioPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(Color.WHITE);

        initComponents();
    }

    private void initComponents() {
        // Título
        JLabel lblTitulo = new JLabel("👤 Gestão de Usuários do Sistema");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(44, 62, 80));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        panelCenter.setOpaque(false);

        // Formulário
        JPanel panelForm = new JPanel(new GridLayout(3, 4, 10, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Dados do Usuário de Acesso"));
        panelForm.setBackground(Color.WHITE);

        txtNome = new JTextField();
        txtLogin = new JTextField();
        txtSenha = new JPasswordField();
        cbTipoAcesso = new JComboBox<>(new String[]{"ADMIN", "OPERADOR"});
        cbStatus = new JComboBox<>(new String[]{"Ativo", "Inativo"});

        panelForm.add(new JLabel("Nome Completo:"));
        panelForm.add(txtNome);
        panelForm.add(new JLabel("Login / Usuário:"));
        panelForm.add(txtLogin);
        panelForm.add(new JLabel("Senha:"));
        panelForm.add(txtSenha);
        panelForm.add(new JLabel("Tipo de Acesso:"));
        panelForm.add(cbTipoAcesso);
        panelForm.add(new JLabel("Status:"));
        panelForm.add(cbStatus);

        // Botões
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotoes.setOpaque(false);

        JButton btnSalvar = new JButton("Salvar Usuário");
        JButton btnLimpar = new JButton("Limpar");
        JButton btnExcluir = new JButton("Excluir / Desativar");

        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnLimpar);
        panelBotoes.add(btnExcluir);

        JPanel panelTopContainer = new JPanel(new BorderLayout());
        panelTopContainer.setOpaque(false);
        panelTopContainer.add(panelForm, BorderLayout.CENTER);
        panelTopContainer.add(panelBotoes, BorderLayout.SOUTH);

        panelCenter.add(panelTopContainer, BorderLayout.NORTH);

        // Tabela
        String[] colunas = {"ID", "Nome", "Login", "Tipo Acesso", "Status"};
        tableModel = new DefaultTableModel(colunas, 0);
        tabelaUsuarios = new JTable(tableModel);

        panelCenter.add(new JScrollPane(tabelaUsuarios), BorderLayout.CENTER);

        add(panelCenter, BorderLayout.CENTER);
    }
}