package view;

import dao.AnimalDAO;
import model.Animal;
import util.SessaoUsuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ListagemAnimalView extends JFrame {

    private JTable tabela;
    private DefaultTableModel model;
    private AnimalDAO animalDAO = new AnimalDAO();
    private List<Animal> listaAnimais;

    public ListagemAnimalView() {
        setTitle("ONG AnimalCare - Gerenciamento de Animais");
        setSize(850, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        carregarAnimais();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Topo - Título e Botões
        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("🐾 Animais Cadastrados");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        topPanel.add(lblTitulo, BorderLayout.WEST);

        JPanel btnTopPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnNovo = new JButton("+ Novo Animal");
        btnNovo.setBackground(new Color(46, 204, 113));
        btnNovo.setForeground(Color.WHITE);
        btnNovo.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnNovo.addActionListener(e -> abrirFormularioCadastro(null));

        btnTopPanel.add(btnNovo);
        topPanel.add(btnTopPanel, BorderLayout.EAST);

        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Tabela
        String[] colunas = {"ID", "Nome", "Espécie", "Raça", "Sexo", "Porte", "Status", "Castrado"};
        model = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        tabela = new JTable(model);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        mainPanel.add(new JScrollPane(tabela), BorderLayout.CENTER);

        // Rodapé - Botões de Ação
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        JButton btnEditar = new JButton("Editar Selecionado");
        btnEditar.addActionListener(e -> editarSelecionado());

        JButton btnExcluir = new JButton("Excluir");
        btnExcluir.setBackground(new Color(231, 76, 60));
        btnExcluir.setForeground(Color.WHITE);
        btnExcluir.setEnabled(SessaoUsuario.isAdmin()); // Apenas Admin pode excluir
        btnExcluir.addActionListener(e -> excluirSelecionado());

        JButton btnAtualizar = new JButton("Atualizar Tabela");
        btnAtualizar.addActionListener(e -> carregarAnimais());

        bottomPanel.add(btnEditar);
        bottomPanel.add(btnExcluir);
        bottomPanel.add(btnAtualizar);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void carregarAnimais() {
        model.setRowCount(0);
        listaAnimais = animalDAO.listarTodos();

        for (Animal a : listaAnimais) {
            model.addRow(new Object[]{
                a.getId(),
                a.getNome(),
                a.getEspecie(),
                a.getRaca(),
                a.getSexo(),
                a.getPorte(),
                a.getStatus(),
                a.isCastrado() ? "Sim" : "Não"
            });
        }
    }

    private void abrirFormularioCadastro(Animal animal) {
        CadastroAnimalView dialog = new CadastroAnimalView(this, animal, this::carregarAnimais);
        dialog.setVisible(true);
    }

    private void editarSelecionado() {
        int row = tabela.getSelectedRow();
        if (row >= 0) {
            Animal selecionado = listaAnimais.get(row);
            abrirFormularioCadastro(selecionado);
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um animal na tabela!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void excluirSelecionado() {
        int row = tabela.getSelectedRow();
        if (row >= 0) {
            Animal selecionado = listaAnimais.get(row);
            int opc = JOptionPane.showConfirmDialog(this, "Deseja realmente excluir o animal: " + selecionado.getNome() + "?", "Confirmação", JOptionPane.YES_NO_OPTION);
            
            if (opc == JOptionPane.YES_OPTION) {
                if (animalDAO.excluir(selecionado.getId())) {
                    JOptionPane.showMessageDialog(this, "Animal excluído!");
                    carregarAnimais();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir!", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um animal na tabela!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
}