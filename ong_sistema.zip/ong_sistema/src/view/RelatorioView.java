package view;

import database.Conexao;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RelatorioView extends JFrame {

    private JTextArea txtRelatorio;

    public RelatorioView() {
        setTitle("ONG AnimalCare - Relatório Gerencial");
        setSize(600, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        gerarRelatorioGeral();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("📊 Relatório Sintético do Sistema", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        mainPanel.add(lblTitulo, BorderLayout.NORTH);

        txtRelatorio = new JTextArea();
        txtRelatorio.setEditable(false);
        txtRelatorio.setFont(new Font("Monospaced", Font.PLAIN, 13));
        txtRelatorio.setMargin(new Insets(10, 10, 10, 10));

        mainPanel.add(new JScrollPane(txtRelatorio), BorderLayout.CENTER);

        JButton btnAtualizar = new JButton("Recarregar Dados");
        btnAtualizar.addActionListener(e -> gerarRelatorioGeral());
        mainPanel.add(btnAtualizar, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void gerarRelatorioGeral() {
        StringBuilder sb = new StringBuilder();
        sb.append("==================================================\n");
        sb.append("         RELATÓRIO GERAL - ONG ANIMALCARE        \n");
        sb.append("==================================================\n\n");

        try (Connection conn = Conexao.getConexao()) {
            // 1. Resumo de Animais por Status
            sb.append("🐾 RESUMO DE ANIMAIS:\n");
            String sqlAnimais = "SELECT status, COUNT(*) AS total FROM animais GROUP BY status";
            try (PreparedStatement stmt = conn.prepareStatement(sqlAnimais);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    sb.append(" - ").append(rs.getString("status")).append(": ").append(rs.getInt("total")).append("\n");
                }
            }

            // 2. Resumo de Voluntários
            sb.append("\n👥 RESUMO DE VOLUNTÁRIOS:\n");
            String sqlVoluntarios = "SELECT status, COUNT(*) AS total FROM voluntarios GROUP BY status";
            try (PreparedStatement stmt = conn.prepareStatement(sqlVoluntarios);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    sb.append(" - Status '").append(rs.getString("status")).append("': ").append(rs.getInt("total")).append("\n");
                }
            }

            // 3. Resumo de Adoções
            sb.append("\n🏠 TOTAL DE ADOÇÕES REGISTRADAS:\n");
            String sqlAdocoes = "SELECT COUNT(*) AS total FROM adocoes";
            try (PreparedStatement stmt = conn.prepareStatement(sqlAdocoes);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    sb.append(" - Concluídas: ").append(rs.getInt("total")).append("\n");
                }
            }

            sb.append("\n==================================================\n");
            sb.append("Relatório gerado com sucesso via ong_animalcare.\n");

        } catch (Exception e) {
            sb.append("\nErro ao gerar relatório: ").append(e.getMessage());
        }

        txtRelatorio.setText(sb.toString());
    }
}