package view;

import dao.AnimalDAO;
import model.Animal;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;

public class CadastroAnimalView extends JDialog {

    private JTextField txtNome, txtRaca, txtCor, txtIdade, txtPeso, txtVacinas;
    private JComboBox<String> cbEspecie, cbSexo, cbPorte, cbStatus;
    private JCheckBox chkCastrado;
    private JTextArea txtObservacoes;

    private Animal animalEdicao;
    private Runnable onSalvarCallback;

    public CadastroAnimalView(Frame parent, Animal animal, Runnable onSalvarCallback) {
        super(parent, animal == null ? "Cadastrar Novo Animal" : "Editar Animal", true);
        this.animalEdicao = animal;
        this.onSalvarCallback = onSalvarCallback;

        setSize(500, 600);
        setLocationRelativeTo(parent);
        setResizable(false);

        initComponents();
        if (animalEdicao != null) {
            preencherCampos();
        }
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(Color.WHITE);

        JPanel formPanel = new JPanel(new GridLayout(11, 2, 8, 8));
        formPanel.setOpaque(false);

        txtNome = new JTextField();
        cbEspecie = new JComboBox<>(new String[]{"Cachorro", "Gato", "Outro"});
        txtRaca = new JTextField();
        cbSexo = new JComboBox<>(new String[]{"Macho", "Fêmea"});
        txtIdade = new JTextField();
        cbPorte = new JComboBox<>(new String[]{"Pequeno", "Médio", "Grande"});
        txtCor = new JTextField();
        txtPeso = new JTextField();
        cbStatus = new JComboBox<>(new String[]{"Disponivel para adocao", "Em tratamento", "Adotado", "Em lar temporario"});
        chkCastrado = new JCheckBox("Sim");
        chkCastrado.setOpaque(false);
        txtVacinas = new JTextField();

        formPanel.add(new JLabel("Nome:"));
        formPanel.add(txtNome);
        formPanel.add(new JLabel("Espécie:"));
        formPanel.add(cbEspecie);
        formPanel.add(new JLabel("Raça:"));
        formPanel.add(txtRaca);
        formPanel.add(new JLabel("Sexo:"));
        formPanel.add(cbSexo);
        formPanel.add(new JLabel("Idade (Anos):"));
        formPanel.add(txtIdade);
        formPanel.add(new JLabel("Porte:"));
        formPanel.add(cbPorte);
        formPanel.add(new JLabel("Cor:"));
        formPanel.add(txtCor);
        formPanel.add(new JLabel("Peso (kg):"));
        formPanel.add(txtPeso);
        formPanel.add(new JLabel("Status:"));
        formPanel.add(cbStatus);
        formPanel.add(new JLabel("Castrado?"));
        formPanel.add(chkCastrado);
        formPanel.add(new JLabel("Vacinas:"));
        formPanel.add(txtVacinas);

        mainPanel.add(formPanel, BorderLayout.NORTH);

        // Observações (área maior)
        JPanel obsPanel = new JPanel(new BorderLayout(5, 5));
        obsPanel.setOpaque(false);
        obsPanel.add(new JLabel("Observações:"), BorderLayout.NORTH);
        txtObservacoes = new JTextArea(4, 20);
        txtObservacoes.setLineWrap(true);
        obsPanel.add(new JScrollPane(txtObservacoes), BorderLayout.CENTER);

        mainPanel.add(obsPanel, BorderLayout.CENTER);

        // Botoes
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setOpaque(false);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBackground(new Color(46, 204, 113));
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.addActionListener(e -> salvar());

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dispose());

        btnPanel.add(btnCancelar);
        btnPanel.add(btnSalvar);

        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void preencherCampos() {
        txtNome.setText(animalEdicao.getNome());
        cbEspecie.setSelectedItem(animalEdicao.getEspecie());
        txtRaca.setText(animalEdicao.getRaca());
        cbSexo.setSelectedItem(animalEdicao.getSexo());
        txtIdade.setText(String.valueOf(animalEdicao.getIdadeAnos()));
        cbPorte.setSelectedItem(animalEdicao.getPorte());
        txtCor.setText(animalEdicao.getCor());
        txtPeso.setText(animalEdicao.getPeso() != null ? animalEdicao.getPeso().toString() : "");
        cbStatus.setSelectedItem(animalEdicao.getStatus());
        chkCastrado.setSelected(animalEdicao.isCastrado());
        txtVacinas.setText(animalEdicao.getVacinas());
        txtObservacoes.setText(animalEdicao.getObservacoes());
    }

    private void salvar() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "O nome do animal é obrigatório!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Animal a = (animalEdicao == null) ? new Animal() : animalEdicao;
        a.setNome(txtNome.getText().trim());
        a.setEspecie((String) cbEspecie.getSelectedItem());
        a.setRaca(txtRaca.getText().trim());
        a.setSexo((String) cbSexo.getSelectedItem());
        
        try {
            a.setIdadeAnos(txtIdade.getText().trim().isEmpty() ? 0 : Integer.parseInt(txtIdade.getText().trim()));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Idade inválida!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        a.setPorte((String) cbPorte.getSelectedItem());
        a.setCor(txtCor.getText().trim());

        try {
            a.setPeso(txtPeso.getText().trim().isEmpty() ? new BigDecimal("0.00") : new BigDecimal(txtPeso.getText().trim().replace(",", ".")));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Peso inválido! Use números (ex: 5.5)", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        a.setStatus((String) cbStatus.getSelectedItem());
        a.setCastrado(chkCastrado.isSelected());
        a.setVacinas(txtVacinas.getText().trim());
        a.setObservacoes(txtObservacoes.getText().trim());

        AnimalDAO dao = new AnimalDAO();
        boolean sucesso = (animalEdicao == null) ? dao.salvar(a) : dao.atualizar(a);

        if (sucesso) {
            JOptionPane.showMessageDialog(this, "Animal salvo com sucesso!");
            if (onSalvarCallback != null) onSalvarCallback.run();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar no banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}