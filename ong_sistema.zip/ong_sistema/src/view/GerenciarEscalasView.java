package view;

import dao.EscalaDAO;
import dao.VoluntarioDAO;
import model.Escala;
import model.Voluntario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public class GerenciarEscalasView extends JFrame {

    private JTable tabela;
    private DefaultTableModel model;
    private EscalaDAO escalaDAO = new EscalaDAO();
    private List<Escala> listaEscalas;

    public GerenciarEscalasView() {
        setTitle("ONG AnimalCare - Escalas e Presenças");
        setSize(850, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        carregarEscalas();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Topo
        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("📅 Escalas de Voluntários");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        topPanel.add(lblTitulo, BorderLayout.WEST);

        JButton btnAgendar = new JButton("+ Agendar Voluntário");
        btnAgendar.setBackground(new Color(52, 152, 219));
        btnAgendar.setForeground(Color.WHITE);
        btnAgendar.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnAgendar.addActionListener(e -> abrirModalAgendamento());
        topPanel.add(btnAgendar, BorderLayout.EAST);

        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Tabela
        String[] colunas = {"ID", "Voluntário", "Data", "Turno", "Função", "Presença"};
        model = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        tabela = new JTable(model);
        tabela.setRowHeight(25);
        tabela.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        mainPanel.add(new JScrollPane(tabela), BorderLayout.CENTER);

        // Rodapé (Marcação de Presença)
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton btnPresente = new JButton("✔ Marcar Presente");
        btnPresente.setBackground(new Color(46, 204, 113));
        btnPresente.setForeground(Color.WHITE);
        btnPresente.addActionListener(e -> marcarPresenca("Presente"));

        JButton btnAusente = new JButton("✖ Marcar Ausente");
        btnAusente.setBackground(new Color(231, 76, 60));
        btnAusente.setForeground(Color.WHITE);
        btnAusente.addActionListener(e -> marcarPresenca("Ausente"));

        JButton btnAtualizar = new JButton("Atualizar");
        btnAtualizar.addActionListener(e -> carregarEscalas());

        bottomPanel.add(btnPresente);
        bottomPanel.add(btnAusente);
        bottomPanel.add(btnAtualizar);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void carregarEscalas() {
        model.setRowCount(0);
        listaEscalas = escalaDAO.listarEscalas();

        for (Escala e : listaEscalas) {
            model.addRow(new Object[]{
                e.getId(),
                e.getNomeVoluntario(),
                e.getDataEscala(),
                e.getTurno(),
                e.getFuncao(),
                e.getStatusPresenca()
            });
        }
    }

    private void marcarPresenca(String novoStatus) {
        int row = tabela.getSelectedRow();
        if (row >= 0) {
            Escala escala = listaEscalas.get(row);
            if (escalaDAO.atualizarPresenca(escala.getId(), novoStatus)) {
                JOptionPane.showMessageDialog(this, "Presença atualizada para: " + novoStatus);
                carregarEscalas();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao atualizar no banco.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma escala na tabela!", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void abrirModalAgendamento() {
        JDialog dialog = new JDialog(this, "Agendar Voluntário em Escala", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        VoluntarioDAO vDao = new VoluntarioDAO();
        List<Voluntario> voluntarios = vDao.listarTodos();

        JComboBox<VoluntarioCombo> cbVoluntarios = new JComboBox<>();
        for (Voluntario v : voluntarios) {
            cbVoluntarios.addItem(new VoluntarioCombo(v.getId(), v.getNomeUsuario()));
        }

        JTextField txtData = new JTextField(LocalDate.now().toString()); // AAAA-MM-DD
        JComboBox<String> cbTurno = new JComboBox<>(new String[]{"Manhã", "Tarde", "Noite"});
        JTextField txtFuncao = new JTextField("Cuidados Gerais");

        panel.add(new JLabel("Voluntário:"));
        panel.add(cbVoluntarios);
        panel.add(new JLabel("Data (AAAA-MM-DD):"));
        panel.add(txtData);
        panel.add(new JLabel("Turno:"));
        panel.add(cbTurno);
        panel.add(new JLabel("Função:"));
        panel.add(txtFuncao);

        JButton btnSalvar = new JButton("Salvar Escala");
        btnSalvar.setBackground(new Color(46, 204, 113));
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.addActionListener(ev -> {
            VoluntarioCombo selected = (VoluntarioCombo) cbVoluntarios.getSelectedItem();
            if (selected == null) return;

            try {
                Date data = Date.valueOf(txtData.getText().trim());
                String turno = (String) cbTurno.getSelectedItem();
                String funcao = txtFuncao.getText().trim();

                if (escalaDAO.agendarEscala(selected.id, data, turno, funcao)) {
                    JOptionPane.showMessageDialog(dialog, "Escala agendada com sucesso!");
                    dialog.dispose();
                    carregarEscalas();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Erro ao agendar escala.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Data em formato inválido! Use AAAA-MM-DD.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(panel, BorderLayout.CENTER);
        dialog.add(btnSalvar, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // Helper interno para renderizar nome no JComboBox
    private static class VoluntarioCombo {
        int id;
        String nome;

        VoluntarioCombo(int id, String nome) {
            this.id = id;
            this.nome = nome;
        }

        @Override
        public String toString() {
            return nome;
        }
    }
}