package view;

import dao.AdocaoDAO;
import dao.AnimalDAO;
import model.Animal;
import util.SessaoUsuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class RegistrarAdocaoView extends JFrame {

    private JComboBox<Animal> cbAnimais;
    private JTextField txtAdotanteId;
    private JTextArea txtObservacoes;

    public RegistrarAdocaoView() {
        setTitle("ONG AnimalCare - Registrar Adoção");
        setSize(450, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        carregarAnimaisDisponiveis();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("🏠 Nova Adoção", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        mainPanel.add(lblTitulo, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        cbAnimais = new JComboBox<>();
        txtAdotanteId = new JTextField("1"); // ID do Adotante cadastrado no banco (Ex: Fernanda - ID 1)

        formPanel.add(new JLabel("Animal Disponível:"));
        formPanel.add(cbAnimais);
        formPanel.add(new JLabel("ID do Adotante:"));
        formPanel.add(txtAdotanteId);

        mainPanel.add(formPanel, BorderLayout.NORTH);

        JPanel obsPanel = new JPanel(new BorderLayout(5, 5));
        obsPanel.add(new JLabel("Observações da Adoção:"), BorderLayout.NORTH);
        txtObservacoes = new JTextArea(5, 20);
        obsPanel.add(new JScrollPane(txtObservacoes), BorderLayout.CENTER);

        mainPanel.add(obsPanel, BorderLayout.CENTER);

        JButton btnConfirmar = new JButton("Confirmar Adoção");
        btnConfirmar.setBackground(new Color(46, 204, 113));
        btnConfirmar.setForeground(Color.WHITE);
        btnConfirmar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnConfirmar.addActionListener(e -> confirmarAdocao());

        mainPanel.add(btnConfirmar, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void carregarAnimaisDisponiveis() {
        AnimalDAO dao = new AnimalDAO();
        List<Animal> lista = dao.listarTodos();

        cbAnimais.removeAllItems();
        for (Animal a : lista) {
            if ("Disponivel para adocao".equalsIgnoreCase(a.getStatus())) {
                cbAnimais.addItem(a);
            }
        }
    }

    private void confirmarAdocao() {
        Animal animalSelecionado = (Animal) cbAnimais.getSelectedItem();
        if (animalSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Nenhum animal selecionado!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int adotanteId = Integer.parseInt(txtAdotanteId.getText().trim());
            int funcionarioId = SessaoUsuario.getUsuarioLogado() != null ? SessaoUsuario.getUsuarioLogado().getId() : 1;

            AdocaoDAO dao = new AdocaoDAO();
            boolean ok = dao.realizarAdocao(animalSelecionado.getId(), adotanteId, funcionarioId, txtObservacoes.getText().trim());

            if (ok) {
                JOptionPane.showMessageDialog(this, "Adoção realizada e registrada com sucesso!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao registrar a adoção no banco.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID do adotante deve ser um número válido!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}