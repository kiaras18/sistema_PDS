package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class EscalaPresencaPanel extends JPanel {

    private JComboBox<String> cbVoluntario;
    private JTextField txtDataEscala;
    private JComboBox<String> cbTurno, cbStatus;
    private JTable tabelaEscalas;
    private DefaultTableModel tableModel;

    public EscalaPresencaPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(Color.WHITE);

        initComponents();
    }

    private void initComponents() {
        // Título
        JLabel lblTitulo = new JLabel("📅 Escalas e Controle de Presença");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(44, 62, 80));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        panelCenter.setOpaque(false);

        // Formulário
        JPanel panelForm = new JPanel(new GridLayout(2, 4, 10, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Agendamento de Escala / Presença"));
        panelForm.setBackground(Color.WHITE);

        cbVoluntario = new JComboBox<>(new String[]{"-- Selecione o Voluntário --"});
        txtDataEscala = new JTextField();
        cbTurno = new JComboBox<>(new String[]{"Manhã (08:00 - 12:00)", "Tarde (13:00 - 17:00)", "Noite (18:00 - 22:00)"});
        cbStatus = new JComboBox<>(new String[]{"Agendado", "Presente", "Ausente", "Justificado"});

        panelForm.add(new JLabel("Voluntário:"));
        panelForm.add(cbVoluntario);
        panelForm.add(new JLabel("Data (dd/mm/aaaa):"));
        panelForm.add(txtDataEscala);
        panelForm.add(new JLabel("Turno:"));
        panelForm.add(cbTurno);
        panelForm.add(new JLabel("Status Presença:"));
        panelForm.add(cbStatus);

        // Botões
        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotoes.setOpaque(false);

        JButton btnSalvar = new JButton("Agendar / Salvar");
        JButton btnLimpar = new JButton("Limpar");
        JButton btnExcluir = new JButton("Excluir");

        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnLimpar);
        panelBotoes.add(btnExcluir);

        JPanel panelTopContainer = new JPanel(new BorderLayout());
        panelTopContainer.setOpaque(false);
        panelTopContainer.add(panelForm, BorderLayout.CENTER);
        panelTopContainer.add(panelBotoes, BorderLayout.SOUTH);

        panelCenter.add(panelTopContainer, BorderLayout.NORTH);

        // Tabela
        String[] colunas = {"ID", "Voluntário", "Data", "Turno", "Status Presença"};
        tableModel = new DefaultTableModel(colunas, 0);
        tabelaEscalas = new JTable(tableModel);

        panelCenter.add(new JScrollPane(tabelaEscalas), BorderLayout.CENTER);

        add(panelCenter, BorderLayout.CENTER);
    }
}