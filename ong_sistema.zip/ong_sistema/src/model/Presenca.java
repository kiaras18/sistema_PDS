package model;

import java.util.Date;

public class Presenca {
    private int id;
    private Integer escalaId;
    private Escala escala;
    private int voluntarioId;
    private Voluntario voluntario;
    private Date dataPresenca;
    private String horaEntrada;
    private String horaSaida;
    private String atividade;
    private String status; // Presente, Ausente, Atrasado, Justificado
    private String observacoes;

    public Presenca() {}

    public Presenca(int id, Integer escalaId, Escala escala, int voluntarioId, Voluntario voluntario, 
                    Date dataPresenca, String horaEntrada, String horaSaida, String atividade, 
                    String status, String observacoes) {
        this.id = id;
        this.escalaId = escalaId;
        this.escala = escala;
        this.voluntarioId = voluntarioId;
        this.voluntario = voluntario;
        this.dataPresenca = dataPresenca;
        this.horaEntrada = horaEntrada;
        this.horaSaida = horaSaida;
        this.atividade = atividade;
        this.status = status;
        this.observacoes = observacoes;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Integer getEscalaId() { return escalaId; }
    public void setEscalaId(Integer escalaId) { this.escalaId = escalaId; }

    public Escala getEscala() { return escala; }
    public void setEscala(Escala escala) { this.escala = escala; }

    public int getVoluntarioId() { return voluntarioId; }
    public void setVoluntarioId(int voluntarioId) { this.voluntarioId = voluntarioId; }

    public Voluntario getVoluntario() { return voluntario; }
    public void setVoluntario(Voluntario voluntario) { this.voluntario = voluntario; }

    public Date getDataPresenca() { return dataPresenca; }
    public void setDataPresenca(Date dataPresenca) { this.dataPresenca = dataPresenca; }

    public String getHoraEntrada() { return horaEntrada; }
    public void setHoraEntrada(String horaEntrada) { this.horaEntrada = horaEntrada; }

    public String getHoraSaida() { return horaSaida; }
    public void setHoraSaida(String horaSaida) { this.horaSaida = horaSaida; }

    public String getAtividade() { return atividade; }
    public void setAtividade(String atividade) { this.atividade = atividade; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
}