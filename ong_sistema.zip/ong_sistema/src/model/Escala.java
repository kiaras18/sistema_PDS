package model;

import java.sql.Date;

public class Escala {
    private int id;
    private int voluntarioId;
    private String nomeVoluntario;
    private Date dataEscala;
    private String turno;
    private String funcao;
    private String statusPresenca; // 'Pendente', 'Presente', 'Ausente', 'Justificado'

    public Escala() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getVoluntarioId() { return voluntarioId; }
    public void setVoluntarioId(int voluntarioId) { this.voluntarioId = voluntarioId; }

    public String getNomeVoluntario() { return nomeVoluntario; }
    public void setNomeVoluntario(String nomeVoluntario) { this.nomeVoluntario = nomeVoluntario; }

    public Date getDataEscala() { return dataEscala; }
    public void setDataEscala(Date dataEscala) { this.dataEscala = dataEscala; }

    public String getTurno() { return turno; }
    public void setTurno(String turno) { this.turno = turno; }

    public String getFuncao() { return funcao; }
    public void setFuncao(String funcao) { this.funcao = funcao; }

    public String getStatusPresenca() { return statusPresenca; }
    public void setStatusPresenca(String statusPresenca) { this.statusPresenca = statusPresenca; }
}