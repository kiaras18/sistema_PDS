package model;

public class Usuario {
    private int id;
    private String nome;
    private String cpf;
    private String email;
    private String senhaHash;
    private String tipoAcesso; // ADMINISTRADOR ou FUNCIONARIO
    private String categoria;  // FUNCIONARIO, VOLUNTARIO, ADOTANTE
    private String telefone;
    private String status;     // ATIVO ou INATIVO

    public Usuario() {}

    public Usuario(int id, String nome, String cpf, String email, String tipoAcesso, String categoria, String telefone, String status) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.tipoAcesso = tipoAcesso;
        this.categoria = categoria;
        this.telefone = telefone;
        this.status = status;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenhaHash() { return senhaHash; }
    public void setSenhaHash(String senhaHash) { this.senhaHash = senhaHash; }

    public String getTipoAcesso() { return tipoAcesso; }
    public void setTipoAcesso(String tipoAcesso) { this.tipoAcesso = tipoAcesso; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}