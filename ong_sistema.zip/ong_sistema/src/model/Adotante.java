package model;

public class Adotante {
    private int id;
    private int usuarioId;
    private Usuario usuario;
    private String profissao;
    private double rendaEstimada;
    private String tipoResidencia; // Casa, Apartamento, Sitio/Chacara
    private boolean possuiOutrosAnimais;
    private String observacoes;

    public Adotante() {}

    public Adotante(int id, int usuarioId, Usuario usuario, String profissao, 
                    double rendaEstimada, String tipoResidencia, boolean possuiOutrosAnimais, 
                    String observacoes) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.usuario = usuario;
        this.profissao = profissao;
        this.rendaEstimada = rendaEstimada;
        this.tipoResidencia = tipoResidencia;
        this.possuiOutrosAnimais = possuiOutrosAnimais;
        this.observacoes = observacoes;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUsuarioId() { return usuarioId; }
    public void setUsuarioId(int usuarioId) { this.usuarioId = usuarioId; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public String getProfissao() { return profissao; }
    public void setProfissao(String profissao) { this.profissao = profissao; }

    public double getRendaEstimada() { return rendaEstimada; }
    public void setRendaEstimada(double rendaEstimada) { this.rendaEstimada = rendaEstimada; }

    public String getTipoResidencia() { return tipoResidencia; }
    public void setTipoResidencia(String tipoResidencia) { this.tipoResidencia = tipoResidencia; }

    public boolean isPossuiOutrosAnimais() { return possuiOutrosAnimais; }
    public void setPossuiOutrosAnimais(boolean possuiOutrosAnimais) { this.possuiOutrosAnimais = possuiOutrosAnimais; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }

    @Override
    public String toString() {
        return (usuario != null) ? usuario.getNome() + " (" + usuario.getCpf() + ")" : "Adotante ID " + id;
    }
}