package model;

import java.math.BigDecimal;
import java.sql.Date;

public class Animal {
    private int id;
    private String nome;
    private String especie;
    private String raca;
    private String sexo;
    private int idadeAnos;
    private String porte;
    private String cor;
    private BigDecimal peso;
    private Date dataResgate;
    private String localResgate;
    private String status;
    private boolean castrado;
    private String vacinas;
    private String observacoes;

    public Animal() {}

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEspecie() { return especie; }
    public void setEspecie(String especie) { this.especie = especie; }

    public String getRaca() { return raca; }
    public void setRaca(String raca) { this.raca = raca; }

    public String getSexo() { return sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }

    public int getIdadeAnos() { return idadeAnos; }
    public void setIdadeAnos(int idadeAnos) { this.idadeAnos = idadeAnos; }

    public String getPorte() { return porte; }
    public void setPorte(String porte) { this.porte = porte; }

    public String getCor() { return cor; }
    public void setCor(String cor) { this.cor = cor; }

    public BigDecimal getPeso() { return peso; }
    public void setPeso(BigDecimal peso) { this.peso = peso; }

    public Date getDataResgate() { return dataResgate; }
    public void setDataResgate(Date dataResgate) { this.dataResgate = dataResgate; }

    public String getLocalResgate() { return localResgate; }
    public void setLocalResgate(String localResgate) { this.localResgate = localResgate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isCastrado() { return castrado; }
    public void setCastrado(boolean castrado) { this.castrado = castrado; }

    public String getVacinas() { return vacinas; }
    public void setVacinas(String vacinas) { this.vacinas = vacinas; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }

    @Override
    public String toString() {
        return nome + " (" + especie + " - " + status + ")";
    }
}