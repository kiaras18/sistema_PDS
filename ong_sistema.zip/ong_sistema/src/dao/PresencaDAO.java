package dao;

import database.Conexao;
import model.Presenca;
import model.Escala;
import model.Voluntario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PresencaDAO {

    private final VoluntarioDAO voluntarioDAO = new VoluntarioDAO();
    private final EscalaDAO escalaDAO = new EscalaDAO();

    public int salvar(Presenca p) throws SQLException {
        String sql = "INSERT INTO presencas (escala_id, voluntario_id, data_presenca, hora_entrada, hora_saida, atividade, status, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            if (p.getEscalaId() != null && p.getEscalaId() > 0) {
                stmt.setInt(1, p.getEscalaId());
            } else {
                stmt.setNull(1, Types.INTEGER);
            }
            stmt.setInt(2, p.getVoluntarioId());
            stmt.setDate(3, new java.sql.Date(p.getDataPresenca().getTime()));
            stmt.setTime(4, Time.valueOf(p.getHoraEntrada().length() == 5 ? p.getHoraEntrada() + ":00" : p.getHoraEntrada()));
            if (p.getHoraSaida() != null && !p.getHoraSaida().isEmpty()) {
                stmt.setTime(5, Time.valueOf(p.getHoraSaida().length() == 5 ? p.getHoraSaida() + ":00" : p.getHoraSaida()));
            } else {
                stmt.setNull(5, Types.TIME);
            }
            stmt.setString(6, p.getAtividade());
            stmt.setString(7, p.getStatus());
            stmt.setString(8, p.getObservacoes());

            stmt.executeUpdate();
            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int generatedId = rs.getInt(1);
                p.setId(generatedId);
                return generatedId;
            }
            return 0;
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
    }

    public boolean atualizar(Presenca p) throws SQLException {
        String sql = "UPDATE presencas SET escala_id=?, voluntario_id=?, data_presenca=?, hora_entrada=?, hora_saida=?, atividade=?, status=?, observacoes=? WHERE id=?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(sql);
            if (p.getEscalaId() != null && p.getEscalaId() > 0) {
                stmt.setInt(1, p.getEscalaId());
            } else {
                stmt.setNull(1, Types.INTEGER);
            }
            stmt.setInt(2, p.getVoluntarioId());
            stmt.setDate(3, new java.sql.Date(p.getDataPresenca().getTime()));
            stmt.setTime(4, Time.valueOf(p.getHoraEntrada().length() == 5 ? p.getHoraEntrada() + ":00" : p.getHoraEntrada()));
            if (p.getHoraSaida() != null && !p.getHoraSaida().isEmpty()) {
                stmt.setTime(5, Time.valueOf(p.getHoraSaida().length() == 5 ? p.getHoraSaida() + ":00" : p.getHoraSaida()));
            } else {
                stmt.setNull(5, Types.TIME);
            }
            stmt.setString(6, p.getAtividade());
            stmt.setString(7, p.getStatus());
            stmt.setString(8, p.getObservacoes());
            stmt.setInt(9, p.getId());

            return stmt.executeUpdate() > 0;
        } finally {
            Conexao.fecharRecursos(stmt, null);
        }
    }

    public boolean excluir(int id) throws SQLException {
        String sql = "DELETE FROM presencas WHERE id = ?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } finally {
            Conexao.fecharRecursos(stmt, null);
        }
    }

    public Presenca buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM presencas WHERE id = ?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return mapearPresenca(rs);
            }
            return null;
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
    }

    public List<Presenca> listarTodas() throws SQLException {
        List<Presenca> lista = new ArrayList<>();
        String sql = "SELECT * FROM presencas ORDER BY data_presenca DESC, hora_entrada DESC";
        Connection conn = Conexao.getConexao();
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                lista.add(mapearPresenca(rs));
            }
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
        return lista;
    }

    public List<Presenca> listarPorVoluntario(int voluntarioId) throws SQLException {
        List<Presenca> lista = new ArrayList<>();
        String sql = "SELECT * FROM presencas WHERE voluntario_id = ? ORDER BY data_presenca DESC";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, voluntarioId);
            rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapearPresenca(rs));
            }
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
        return lista;
    }

    private Presenca mapearPresenca(ResultSet rs) throws SQLException {
        Presenca p = new Presenca();
        p.setId(rs.getInt("id"));
        int escId = rs.getInt("escala_id");
        if (!rs.wasNull()) {
            p.setEscalaId(escId);
            Escala e = escalaDAO.buscarPorId(escId);
            p.setEscala(e);
        }
        p.setVoluntarioId(rs.getInt("voluntario_id"));
        p.setDataPresenca(rs.getDate("data_presenca"));
        p.setHoraEntrada(rs.getTime("hora_entrada").toString().substring(0, 5));
        Time hSaida = rs.getTime("hora_saida");
        if (hSaida != null) {
            p.setHoraSaida(hSaida.toString().substring(0, 5));
        }
        p.setAtividade(rs.getString("atividade"));
        p.setStatus(rs.getString("status"));
        p.setObservacoes(rs.getString("observacoes"));

        Voluntario v = voluntarioDAO.buscarPorId(p.getVoluntarioId());
        p.setVoluntario(v);

        return p;
    }
}