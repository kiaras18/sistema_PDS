package dao;

import database.Conexao;
import model.Animal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnimalDAO {

    public boolean salvar(Animal a) {
        String sql = "INSERT INTO animais (nome, especie, raca, sexo, idade_anos, porte, cor, peso, status, castrado, vacinas, observacoes) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, a.getNome());
            stmt.setString(2, a.getEspecie());
            stmt.setString(3, a.getRaca());
            stmt.setString(4, a.getSexo());
            stmt.setInt(5, a.getIdadeAnos());
            stmt.setString(6, a.getPorte());
            stmt.setString(7, a.getCor());
            stmt.setBigDecimal(8, a.getPeso());
            stmt.setString(9, a.getStatus());
            stmt.setBoolean(10, a.isCastrado());
            stmt.setString(11, a.getVacinas());
            stmt.setString(12, a.getObservacoes());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizar(Animal a) {
        String sql = "UPDATE animais SET nome=?, especie=?, raca=?, sexo=?, idade_anos=?, porte=?, cor=?, peso=?, status=?, castrado=?, vacinas=?, observacoes=? WHERE id=?";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, a.getNome());
            stmt.setString(2, a.getEspecie());
            stmt.setString(3, a.getRaca());
            stmt.setString(4, a.getSexo());
            stmt.setInt(5, a.getIdadeAnos());
            stmt.setString(6, a.getPorte());
            stmt.setString(7, a.getCor());
            stmt.setBigDecimal(8, a.getPeso());
            stmt.setString(9, a.getStatus());
            stmt.setBoolean(10, a.isCastrado());
            stmt.setString(11, a.getVacinas());
            stmt.setString(12, a.getObservacoes());
            stmt.setInt(13, a.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluir(int id) {
        String sql = "DELETE FROM animais WHERE id = ?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Animal> listarTodos() {
        List<Animal> lista = new ArrayList<>();
        String sql = "SELECT * FROM animais ORDER BY id DESC";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Animal a = new Animal();
                a.setId(rs.getInt("id"));
                a.setNome(rs.getString("nome"));
                a.setEspecie(rs.getString("especie"));
                a.setRaca(rs.getString("raca"));
                a.setSexo(rs.getString("sexo"));
                a.setIdadeAnos(rs.getInt("idade_anos"));
                a.setPorte(rs.getString("porte"));
                a.setCor(rs.getString("cor"));
                a.setPeso(rs.getBigDecimal("peso"));
                a.setStatus(rs.getString("status"));
                a.setCastrado(rs.getBoolean("castrado"));
                a.setVacinas(rs.getString("vacinas"));
                a.setObservacoes(rs.getString("observacoes"));
                lista.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public int contarTotal() {
        String sql = "SELECT COUNT(*) FROM animais";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int contarDisponiveis() {
        String sql = "SELECT COUNT(*) FROM animais WHERE status = 'Disponivel para adocao'";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}