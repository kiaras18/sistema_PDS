package dao;

import database.Conexao;
import model.Voluntario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VoluntarioDAO {

    public List<Voluntario> listarTodos() {
        List<Voluntario> lista = new ArrayList<>();
        String sql = "SELECT v.*, u.nome AS usuario_nome, u.telefone AS usuario_telefone " +
                     "FROM voluntarios v " +
                     "INNER JOIN usuarios u ON v.usuario_id = u.id " +
                     "ORDER BY v.id DESC";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Voluntario v = new Voluntario();
                v.setId(rs.getInt("id"));
                v.setUsuarioId(rs.getInt("usuario_id"));
                v.setNomeUsuario(rs.getString("usuario_nome"));
                v.setTelefoneUsuario(rs.getString("usuario_telefone"));
                v.setDisponibilidade(rs.getString("disponibilidade"));
                v.setAreaAtuacao(rs.getString("area_atuacao"));
                v.setDataEntrada(rs.getDate("data_entrada"));
                v.setStatus(rs.getString("status"));
                v.setObservacoes(rs.getString("observacoes"));
                lista.add(v);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}