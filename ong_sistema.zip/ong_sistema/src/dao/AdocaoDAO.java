package dao;

import database.Conexao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class AdocaoDAO {

    public boolean realizarAdocao(int animalId, int adotanteId, int funcionarioId, String observacoes) {
        String sqlAdocao = "INSERT INTO adocoes (animal_id, adotante_id, funcionario_id, data_adocao, status, observacoes) " +
                           "VALUES (?, ?, ?, ?, 'Concluida', ?)";
        String sqlAnimal = "UPDATE animais SET status = 'Adotado' WHERE id = ?";

        Connection conn = null;
        try {
            conn = Conexao.getConexao();
            conn.setAutoCommit(false); // Inicia transação

            // 1. Inserir Registro de Adoção
            try (PreparedStatement stmtAdocao = conn.prepareStatement(sqlAdocao)) {
                stmtAdocao.setInt(1, animalId);
                stmtAdocao.setInt(2, adotanteId);
                stmtAdocao.setInt(3, funcionarioId);
                stmtAdocao.setDate(4, Date.valueOf(LocalDate.now()));
                stmtAdocao.setString(5, observacoes);
                stmtAdocao.executeUpdate();
            }

            // 2. Atualizar Status do Animal
            try (PreparedStatement stmtAnimal = conn.prepareStatement(sqlAnimal)) {
                stmtAnimal.setInt(1, animalId);
                stmtAnimal.executeUpdate();
            }

            conn.commit(); // Confirma alterações no banco
            return true;
        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            e.printStackTrace();
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }
}