package dao;

import database.Conexao;
import model.Adotante;
import model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdotanteDAO {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    public int salvar(Adotante a) throws SQLException {
        String sql = "INSERT INTO adotantes (usuario_id, profissao, renda_estimada, tipo_residencia, possui_outros_animais, observacoes) VALUES (?, ?, ?, ?, ?, ?)";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, a.getUsuarioId());
            stmt.setString(2, a.getProfissao());
            stmt.setDouble(3, a.getRendaEstimada());
            stmt.setString(4, a.getTipoResidencia());
            stmt.setBoolean(5, a.isPossuiOutrosAnimais());
            stmt.setString(6, a.getObservacoes());

            stmt.executeUpdate();
            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int generatedId = rs.getInt(1);
                a.setId(generatedId);
                return generatedId;
            }
            return 0;
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
    }

    public boolean atualizar(Adotante a) throws SQLException {
        String sql = "UPDATE adotantes SET profissao=?, renda_estimada=?, tipo_residencia=?, possui_outros_animais=?, observacoes=? WHERE id=?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, a.getProfissao());
            stmt.setDouble(2, a.getRendaEstimada());
            stmt.setString(3, a.getTipoResidencia());
            stmt.setBoolean(4, a.isPossuiOutrosAnimais());
            stmt.setString(5, a.getObservacoes());
            stmt.setInt(6, a.getId());

            return stmt.executeUpdate() > 0;
        } finally {
            Conexao.fecharRecursos(stmt, null);
        }
    }

    public boolean excluir(int id) throws SQLException {
        String sql = "DELETE FROM adotantes WHERE id = ?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } finally {
            Conexao.fecharRecursos(stmt, null);
        }
    }

    public Adotante buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM adotantes WHERE id = ?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return mapearAdotante(rs);
            }
            return null;
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
    }

    public Adotante buscarPorUsuarioId(int usuarioId) throws SQLException {
        String sql = "SELECT * FROM adotantes WHERE usuario_id = ?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, usuarioId);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return mapearAdotante(rs);
            }
            return null;
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
    }

    public List<Adotante> listarTodos() throws SQLException {
        List<Adotante> lista = new ArrayList<>();
        String sql = "SELECT a.* FROM adotantes a INNER JOIN usuarios u ON a.usuario_id = u.id ORDER BY u.nome ASC";
        Connection conn = Conexao.getConexao();
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                lista.add(mapearAdotante(rs));
            }
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
        return lista;
    }

    private Adotante mapearAdotante(ResultSet rs) throws SQLException {
        Adotante a = new Adotante();
        a.setId(rs.getInt("id"));
        a.setUsuarioId(rs.getInt("usuario_id"));
        a.setProfissao(rs.getString("profissao"));
        a.setRendaEstimada(rs.getDouble("renda_estimada"));
        a.setTipoResidencia(rs.getString("tipo_residencia"));
        a.setPossuiOutrosAnimais(rs.getBoolean("possui_outros_animais"));
        a.setObservacoes(rs.getString("observacoes"));

        Usuario u = usuarioDAO.buscarPorId(a.getUsuarioId());
        a.setUsuario(u);

        return a;
    }
}