package dao;

import database.Conexao;
import model.Escala;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EscalaDAO {

    public boolean agendarEscala(int voluntarioId, Date dataEscala, String turno, String funcao) {
        String sql = "INSERT INTO escalas (voluntario_id, data_escala, turno, funcao, status_presenca) VALUES (?, ?, ?, ?, 'Pendente')";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, voluntarioId);
            stmt.setDate(2, dataEscala);
            stmt.setString(3, turno);
            stmt.setString(4, funcao);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Escala> listarEscalas() {
        List<Escala> lista = new ArrayList<>();
        String sql = "SELECT e.*, u.nome AS voluntario_nome " +
                     "FROM escalas e " +
                     "INNER JOIN voluntarios v ON e.voluntario_id = v.id " +
                     "INNER JOIN usuarios u ON v.usuario_id = u.id " +
                     "ORDER BY e.data_escala DESC, e.turno ASC";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Escala e = new Escala();
                e.setId(rs.getInt("id"));
                e.setVoluntarioId(rs.getInt("voluntario_id"));
                e.setNomeVoluntario(rs.getString("voluntario_nome"));
                e.setDataEscala(rs.getDate("data_escala"));
                e.setTurno(rs.getString("turno"));
                e.setFuncao(rs.getString("funcao"));
                e.setStatusPresenca(rs.getString("status_presenca"));
                lista.add(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean atualizarPresenca(int escalaId, String novoStatus) {
        String sql = "UPDATE escalas SET status_presenca = ? WHERE id = ?";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, novoStatus);
            stmt.setInt(2, escalaId);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}