package dao;

import database.Conexao;
import model.Escala;
import model.Voluntario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EscalaDAO {

    private final VoluntarioDAO voluntarioDAO = new VoluntarioDAO();

    public int salvar(Escala e) throws SQLException {
        String sql = "INSERT INTO escalas (voluntario_id, data_escala, hora_inicio, hora_fim, atividade, observacoes) VALUES (?, ?, ?, ?, ?, ?)";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, e.getVoluntarioId());
            stmt.setDate(2, new java.sql.Date(e.getDataEscala().getTime()));
            stmt.setTime(3, Time.valueOf(e.getHoraInicio().length() == 5 ? e.getHoraInicio() + ":00" : e.getHoraInicio()));
            stmt.setTime(4, Time.valueOf(e.getHoraFim().length() == 5 ? e.getHoraFim() + ":00" : e.getHoraFim()));
            stmt.setString(5, e.getAtividade());
            stmt.setString(6, e.getObservacoes());

            stmt.executeUpdate();
            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int generatedId = rs.getInt(1);
                e.setId(generatedId);
                return generatedId;
            }
            return 0;
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
    }

    public boolean atualizar(Escala e) throws SQLException {
        String sql = "UPDATE escalas SET voluntario_id=?, data_escala=?, hora_inicio=?, hora_fim=?, atividade=?, observacoes=? WHERE id=?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, e.getVoluntarioId());
            stmt.setDate(2, new java.sql.Date(e.getDataEscala().getTime()));
            stmt.setTime(3, Time.valueOf(e.getHoraInicio().length() == 5 ? e.getHoraInicio() + ":00" : e.getHoraInicio()));
            stmt.setTime(4, Time.valueOf(e.getHoraFim().length() == 5 ? e.getHoraFim() + ":00" : e.getHoraFim()));
            stmt.setString(5, e.getAtividade());
            stmt.setString(6, e.getObservacoes());
            stmt.setInt(7, e.getId());

            return stmt.executeUpdate() > 0;
        } finally {
            Conexao.fecharRecursos(stmt, null);
        }
    }

    public boolean excluir(int id) throws SQLException {
        String sql = "DELETE FROM escalas WHERE id = ?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } finally {
            Conexao.fecharRecursos(stmt, null);
        }
    }

    public Escala buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM escalas WHERE id = ?";
        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return mapearEscala(rs);
            }
            return null;
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
    }

    public List<Escala> listarTodas() throws SQLException {
        return filtrar(null, null, null);
    }

    public List<Escala> filtrar(String dataSql, Integer voluntarioId, String atividade) throws SQLException {
        List<Escala> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM escalas WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (dataSql != null && !dataSql.trim().isEmpty()) {
            sql.append(" AND data_escala = ?");
            params.add(Date.valueOf(dataSql));
        }
        if (voluntarioId != null && voluntarioId > 0) {
            sql.append(" AND voluntario_id = ?");
            params.add(voluntarioId);
        }
        if (atividade != null && !atividade.trim().isEmpty() && !atividade.equalsIgnoreCase("Todas")) {
            sql.append(" AND atividade = ?");
            params.add(atividade);
        }

        sql.append(" ORDER BY data_escala DESC, hora_inicio ASC");

        Connection conn = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(sql.toString());
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }
            rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapearEscala(rs));
            }
        } finally {
            Conexao.fecharRecursos(stmt, rs);
        }
        return lista;
    }

    private Escala mapearEscala(ResultSet rs) throws SQLException {
        Escala e = new Escala();
        e.setId(rs.getInt("id"));
        e.setVoluntarioId(rs.getInt("voluntario_id"));
        e.setDataEscala(rs.getDate("data_escala"));
        e.setHoraInicio(rs.getTime("hora_inicio").toString().substring(0, 5));
        e.setHoraFim(rs.getTime("hora_fim").toString().substring(0, 5));
        e.setAtividade(rs.getString("atividade"));
        e.setObservacoes(rs.getString("observacoes"));

        Voluntario v = voluntarioDAO.buscarPorId(e.getVoluntarioId());
        e.setVoluntario(v);

        return e;
    }
}