package dao;

import database.Conexao;
import model.Usuario;
import util.HashUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    public Usuario autenticar(String loginOuEmail, String senhaPura) {
        String hashSenha = HashUtil.getSha256(senhaPura);
        String sql = "SELECT * FROM usuarios WHERE (email = ? OR cpf = ?) AND senha_hash = ? AND status = 'ATIVO'";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, loginOuEmail);
            stmt.setString(2, loginOuEmail);
            stmt.setString(3, hashSenha);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId(rs.getInt("id"));
                    u.setNome(rs.getString("nome"));
                    u.setCpf(rs.getString("cpf"));
                    u.setEmail(rs.getString("email"));
                    u.setTipoAcesso(rs.getString("tipo_acesso"));
                    u.setCategoria(rs.getString("categoria"));
                    u.setTelefone(rs.getString("telefone"));
                    u.setStatus(rs.getString("status"));
                    return u;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}