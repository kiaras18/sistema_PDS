import view.LoginView;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class MainApp {

    public static void main(String[] args) {
        // Aplica o visual nativo do sistema operacional para os componentes Swing
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("Nao foi possivel definir o LookAndFeel nativo: " + e.getMessage());
        }

        // Inicializa a interface de Login na thread de eventos Swing (EDT)
        SwingUtilities.invokeLater(() -> {
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
        });
    }
}