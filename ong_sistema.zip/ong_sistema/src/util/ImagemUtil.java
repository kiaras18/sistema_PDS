package util;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class ImagemUtil {

    private static final String UPLOAD_DIR = "resources/uploads/";

    static {
        File dir = new File(UPLOAD_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    /**
     * Redimensiona uma imagem para se ajustar ao tamanho maximo do container mantendo a proporcao.
     */
    public static ImageIcon redimensionarImagem(String caminhoAbsoluto, int larguraAlvo, int alturaAlvo) {
        if (caminhoAbsoluto == null || caminhoAbsoluto.isEmpty()) {
            return null;
        }

        File arquivo = new File(caminhoAbsoluto);
        if (!arquivo.exists()) {
            return null;
        }

        try {
            BufferedImage imgOriginal = ImageIO.read(arquivo);
            if (imgOriginal == null) return null;

            int larguraOrig = imgOriginal.getWidth();
            int alturaOrig = imgOriginal.getHeight();

            double escala = Math.min((double) larguraAlvo / larguraOrig, (double) alturaAlvo / alturaOrig);
            int novaLargura = (int) (larguraOrig * escala);
            int novaAltura = (int) (alturaOrig * escala);

            Image imgEscalada = imgOriginal.getScaledInstance(novaLargura, novaAltura, Image.SCALE_SMOOTH);
            return new ImageIcon(imgEscalada);

        } catch (IOException e) {
            System.err.println("Erro ao carregar e redimensionar imagem: " + e.getMessage());
            return null;
        }
    }

    /**
     * Copia uma imagem selecionada pelo usuario para a pasta interna resources/uploads/
     * @return Caminho relativo do arquivo salvo.
     */
    public static String salvarFotoLocal(File arquivoOrigem) throws IOException {
        if (arquivoOrigem == null || !arquivoOrigem.exists()) {
            return null;
        }

        String nomeOriginal = arquivoOrigem.getName();
        String extensao = "";
        int i = nomeOriginal.lastIndexOf('.');
        if (i > 0) {
            extensao = nomeOriginal.substring(i);
        }

        String novoNome = "animal_" + System.currentTimeMillis() + extensao;
        File destino = new File(UPLOAD_DIR + novoNome);

        Files.copy(arquivoOrigem.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
        return destino.getPath();
    }
}