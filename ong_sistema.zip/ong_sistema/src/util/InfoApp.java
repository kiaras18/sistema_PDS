package util;
/**
* UTIL - as informacoes do software, num lugar so.
*
* A janela "Sobre" le tudo daqui. Para trocar o nome de um autor ou a
* versao, muda-se este arquivo e mais nada.
*/
public final class InfoApp {
	

private InfoApp() { } // so constantes: ninguem cria objeto desta classe

public static final String NOME = "ONG Animal Care";
public static final String VERSAO = "1.0";
public static final String DESCRICAO = "Sistema de gerenciamento de ONG.";
// Troquem pelos nomes de voces.
public static final String[] AUTORES = { "Julia Gabriely Kehl", "Kiara Annelise da Silva Souza"};


public static final String PROFESSOR = "Me. Timoteo Monteiro da Silva";
public static final String INSTITUICAO = "IFSC - Campus Gaspar";
public static final String DISCIPLINA = "Prática e Desenvolvimento de Sistemas II";
public static final String ANO = "2026";
public static final String TECNOLOGIAS = "Java (Swing), padrao MVC, MySQL (JDBC)";
}

