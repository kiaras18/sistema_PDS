package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

public class Validacao {

    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[a-zA-Z]{2,}$");

    /**
     * Valida CPF com calculo de digitos verificadores.
     */
    public static boolean isCpfValido(String cpf) {
        if (cpf == null) return false;
        cpf = cpf.replaceAll("[^0-9]", "");

        if (cpf.length() != 11) return false;

        // Impede sequencias invalidas comuns (11111111111, etc)
        if (cpf.matches("(\\d)\\1{10}")) return false;

        try {
            int soma = 0;
            for (int i = 0; i < 9; i++) {
                soma += (cpf.charAt(i) - '0') * (10 - i);
            }
            int resto = 11 - (soma % 11);
            int digito1 = (resto >= 10) ? 0 : resto;

            if (digito1 != (cpf.charAt(9) - '0')) return false;

            soma = 0;
            for (int i = 0; i < 10; i++) {
                soma += (cpf.charAt(i) - '0') * (11 - i);
            }
            resto = 11 - (soma % 11);
            int digito2 = (resto >= 10) ? 0 : resto;

            return digito2 == (cpf.charAt(10) - '0');
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Valida o formato do e-mail.
     */
    public static boolean isEmailValido(String email) {
        if (email == null || email.trim().isEmpty()) return false;
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    /**
     * Verifica se o campo texto esta preenchido.
     */
    public static boolean isCampoPreenchido(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }

    /**
     * Valida se uma string contem um numero decimal valido e positivo.
     */
    public static boolean isDecimalValido(String valor) {
        if (valor == null || valor.trim().isEmpty()) return false;
        try {
            double v = Double.parseDouble(valor.replace(",", "."));
            return v >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Valida formato de data dd/MM/yyyy.
     */
    public static boolean isDataValida(String dataStr) {
        if (dataStr == null || dataStr.trim().isEmpty()) return false;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        try {
            sdf.parse(dataStr.trim());
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
}