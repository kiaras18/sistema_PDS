package util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class CriptografiaUtil {

    /**
     * Gera o hash SHA-256 da senha em hexadecimal.
     * @param senha Texto limpo da senha
     * @return Hash de 64 caracteres
     */
    public static String gerharHash(String senha) {
        if (senha == null || senha.isEmpty()) {
            return "";
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(senha.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Erro ao criptografar senha: " + e.getMessage());
            return senha;
        }
    }

    /**
     * Compara uma senha em texto puro com um hash fornecido.
     */
    public static boolean compararSenha(String senhaPlana, String hashEsperado) {
        if (senhaPlana == null || hashEsperado == null) return false;
        String hashGerado = gerharHash(senhaPlana);
        return hashGerado.equalsIgnoreCase(hashEsperado);
    }
}	