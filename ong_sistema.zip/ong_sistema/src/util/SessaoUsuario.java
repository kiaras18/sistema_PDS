package util;

import model.Usuario;

public class SessaoUsuario {

    private static Usuario usuarioLogado;

    public static void iniciarSessao(Usuario usuario) {
        usuarioLogado = usuario;
    }

    public static void encerrarSessao() {
        usuarioLogado = null;
    }

    public static boolean isLogado() {
        return usuarioLogado != null;
    }

    public static boolean isAdmin() {
        return isLogado() && "ADMINISTRADOR".equalsIgnoreCase(usuarioLogado.getTipoAcesso());
    }

    public static Usuario getUsuarioLogado() {
        return usuarioLogado;
    }
}