
package view;

import dao.AnimalDAO;
import model.Animal;
import util.ImagemUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.util.List;

public class AnimaisDisponiveisView extends JFrame {

    private JPanel painelAnimais;

    // Guarda se a tela mostrará apenas animais disponíveis
    private boolean somenteDisponiveis;

    public AnimaisDisponiveisView() {
        this(true);
    }

    public AnimaisDisponiveisView(boolean somenteDisponiveis) {

        this.somenteDisponiveis = somenteDisponiveis;

        setTitle(somenteDisponiveis
                ? "AnimalCare - Animais disponíveis para adoção"
                : "AnimalCare - Todos os animais");

        setSize(850, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        carregarAnimais(somenteDisponiveis);
    }

    private void initComponents() {

        JPanel painelPrincipal = new JPanel(new BorderLayout(10, 10));

        painelPrincipal.setBackground(new Color(245, 247, 250));
        painelPrincipal.setBorder(new EmptyBorder(20, 20, 20, 20));

        // TÍTULO DA TELA
        JLabel titulo = new JLabel(
                somenteDisponiveis
                ? "Animais disponíveis para adoção"
                : "Total de animais cadastrados"
        );

        titulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titulo.setForeground(new Color(44, 62, 80));

        painelPrincipal.add(titulo, BorderLayout.NORTH);

        // PAINEL DOS ANIMAIS
        painelAnimais = new JPanel(new GridLayout(0, 3, 15, 15));

        painelAnimais.setBackground(new Color(245, 247, 250));

        JScrollPane scroll = new JScrollPane(painelAnimais);
        scroll.setBorder(null);

        painelPrincipal.add(scroll, BorderLayout.CENTER);

        add(painelPrincipal);
    }

    // CARREGAR ANIMAIS DO BANCO
    private void carregarAnimais(boolean somenteDisponiveis) {

        painelAnimais.removeAll();

        AnimalDAO dao = new AnimalDAO();

        List<Animal> animais;

        if (somenteDisponiveis) {
            animais = dao.listarDisponiveis();
        } else {
            animais = dao.listarTodos();
        }

        if (animais.isEmpty()) {

            JLabel vazio = new JLabel(
                    "Nenhum animal cadastrado.",
                    SwingConstants.CENTER
            );

            vazio.setFont(new Font("Segoe UI", Font.PLAIN, 16));

            painelAnimais.add(vazio);

        } else {

            for (Animal animal : animais) {
                painelAnimais.add(criarCardAnimal(animal));
            }
        }

        painelAnimais.revalidate();
        painelAnimais.repaint();
    }

    // CRIAR CARD DE CADA ANIMAL
    private JPanel criarCardAnimal(Animal animal) {

        JPanel card = new JPanel(new BorderLayout(8, 8));

        card.setBackground(Color.WHITE);

        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(12, 12, 12, 12)
        ));

        // FOTO DO ANIMAL
        JLabel foto = new JLabel("", SwingConstants.CENTER);

        foto.setPreferredSize(new Dimension(180, 150));

        if (animal.getCaminhoImagem() != null
                && !animal.getCaminhoImagem().isEmpty()) {

            ImageIcon imagem = ImagemUtil.redimensionarImagem(
                    animal.getCaminhoImagem(), 180, 150
            );

            if (imagem != null) {
                foto.setIcon(imagem);
            } else {
                foto.setText("Foto não encontrada");
            }

        } else {
            foto.setText("Sem foto cadastrada");
        }

        card.add(foto, BorderLayout.NORTH);

        // INFORMAÇÕES DO ANIMAL
        JPanel informacoes = new JPanel();

        informacoes.setLayout(
                new BoxLayout(informacoes, BoxLayout.Y_AXIS)
        );

        informacoes.setBackground(Color.WHITE);

        JLabel nome = new JLabel(animal.getNome());

        nome.setFont(new Font("Segoe UI", Font.BOLD, 19));
        nome.setForeground(new Color(44, 62, 80));

        informacoes.add(nome);
        informacoes.add(Box.createVerticalStrut(8));

        adicionarInformacao(informacoes, "ID",
                String.valueOf(animal.getId()));

        adicionarInformacao(informacoes, "Espécie",
                animal.getEspecie());

        adicionarInformacao(informacoes, "Raça",
                animal.getRaca());

        adicionarInformacao(informacoes, "Sexo",
                animal.getSexo());

        adicionarInformacao(informacoes, "Idade",
                animal.getIdadeAnos() + " anos");

        adicionarInformacao(informacoes, "Porte",
                animal.getPorte());

        adicionarInformacao(informacoes, "Cor",
                animal.getCor());

        adicionarInformacao(informacoes, "Peso",
                animal.getPeso() != null
                ? animal.getPeso() + " kg"
                : "Não informado");

        adicionarInformacao(informacoes, "Status",
                animal.getStatus());

        adicionarInformacao(informacoes, "Castrado",
                animal.isCastrado() ? "Sim" : "Não");

        adicionarInformacao(informacoes, "Vacinas",
                animal.getVacinas());

        adicionarInformacao(informacoes, "Data de resgate",
                String.valueOf(animal.getDataResgate()));

        adicionarInformacao(informacoes, "Local de resgate",
                animal.getLocalResgate());

        adicionarInformacao(informacoes, "Observações",
                animal.getObservacoes());

        card.add(informacoes, BorderLayout.CENTER);

        return card;
    }

    // ADICIONAR CADA INFORMAÇÃO AO CARD
    private void adicionarInformacao(
            JPanel painel, String titulo, String valor) {

        JLabel label = new JLabel(
                "<html><b>" + titulo + ":</b> "
                + (valor == null || valor.equals("null")
                ? "Não informado" : valor)
                + "</html>"
        );

        label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        label.setForeground(new Color(70, 70, 70));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        painel.add(label);
        painel.add(Box.createVerticalStrut(4));
    }
}
